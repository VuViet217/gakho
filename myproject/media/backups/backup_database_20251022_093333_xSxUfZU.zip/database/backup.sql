-- MySQL dump
-- Database: khoga
-- Date: 2025-10-22 09:33:34.003058

SET FOREIGN_KEY_CHECKS=0;

DROP TABLE IF EXISTS `accounts_user`;
CREATE TABLE `accounts_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `role` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `profile_image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager_id` bigint DEFAULT NULL,
  `manager_email` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `manager_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `accounts_user_manager_id_57cc9038_fk_accounts_user_id` (`manager_id`),
  CONSTRAINT `accounts_user_manager_id_57cc9038_fk_accounts_user_id` FOREIGN KEY (`manager_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `accounts_user` (`id`, `password`, `last_login`, `is_superuser`, `username`, `first_name`, `last_name`, `email`, `is_staff`, `is_active`, `date_joined`, `role`, `department`, `phone`, `profile_image`, `manager_id`, `manager_email`, `manager_name`) VALUES
(1, 'pbkdf2_sha256$1000000$ppgSAdRkeT5V2jNettaBUL$FT8IKqcPhHBgaXakftx9yzwvW3edJBIh5SchqylHQyQ=', '2025-10-22 09:18:52.439661', 0, 'admin', 'admin', 'admin', 'viet.dinhlang@olympus.com', 0, 1, '2025-10-16 02:32:13.730605', 'admin', NULL, NULL, '', NULL, '', NULL),
(2, 'pbkdf2_sha256$1000000$tgkVnHIENVDkWD2SldAf3J$zia2JLONXHlY75Pp7C3cIevhA/n2c4IW8HQlOMBunA4=', '2025-10-21 15:56:05.898164', 0, 'V019935', 'Hoài', 'Nguyễn Thị', 'hoai.nguyenthi@olympus.com', 0, 1, '2025-10-17 09:08:40.747317', 'staff', NULL, NULL, '', 7, 'viet.dinhlang@olympus.com', 'Việt Đinh Lang'),
(3, 'pbkdf2_sha256$1000000$NpnIkfchVNqGasF98nTEdp$NvZZ16Ah3Y23Xqbqd0OB/7GwcUYD0Hdj1qBHKdgJq4Y=', '2025-10-20 08:23:38.639397', 0, 'V003522', 'Lam', 'Trần Thị', 'lam.tranthi@olympus.com', 0, 1, '2025-10-18 06:49:05.011474', 'staff', 'GA', NULL, '', 4, 'nguyet.truongthiminh@olympus.com', 'Nguyệt Trương Thị Minh'),
(4, 'pbkdf2_sha256$1000000$yNljFXmMRTEuvcB0PLBjhT$AiP6gxs6ujGbnOjIT9XXBdOCGGjRPS7Qm1rIWHs7Rlk=', '2025-10-20 08:26:21.217877', 0, 'V006330', 'Nguyệt', 'Trương Thị Minh', 'nguyet.truongthiminh@olympus.com', 0, 1, '2025-10-18 06:49:43.507821', 'staff', 'GA', NULL, '', NULL, '', NULL),
(5, 'pbkdf2_sha256$870000$8dsW9sgieOJnflngCT4wea$5ZNNY4ArDTQ1YGZUCsWs9hBlGEoOhAFI3J4Ushs8Lck=', '2025-10-18 07:16:24.720693', 0, 'V014554', 'Nhành', 'Nguyễn Thị', 'nhanh.nguyenthi@olympus.com', 0, 1, '2025-10-18 07:15:23.978786', 'staff', 'HR', NULL, '', 6, 'ly.nguyenthimai@olympus.com', 'Ly Nguyễn Thị Mai Ly'),
(6, 'pbkdf2_sha256$870000$gWeXHfLaLqnoU1Sl88WpTm$PTFE2WVsq64rQiAIb6vCXCAJ6nTx/gvr6CHKsMHSsqg=', NULL, 0, 'V011755', 'Ly', 'Nguyễn Thị Mai Ly', 'ly.nguyenthimai@olympus.com', 0, 1, '2025-10-18 07:16:09.098478', 'staff', NULL, NULL, '', NULL, '', NULL),
(7, 'pbkdf2_sha256$1000000$4mKE2qcvigCOWcDtMR8FrE$/kFA0cK4knaFgnJPkkjAypWhc6TLeou89Y9PvZYN82c=', '2025-10-22 08:16:38.477224', 0, 'V018283', 'Việt', 'Đinh Lang', 'viet.dinhlang@olympus.com', 0, 1, '2025-10-18 07:24:42.099174', 'staff', NULL, NULL, '', 11, 'quang.phamngoc@olympus.com', 'Quang Phạm Ngọc'),
(8, 'pbkdf2_sha256$1000000$VInWTbHDsAtOCzgQtTGS4w$pDkFUtw2yNlri7b6MHkkSvb8to+yXoRJ0X0kyOi5Ung=', '2025-10-21 16:25:50.196288', 0, 'QuanLyKho', 'Việt', 'Đinh Lang', 'viet.dinhlang@olympus.com', 0, 1, '2025-10-20 01:16:06.927529', 'manager', 'GA', NULL, '', 9, 'dung.tranquang@olympus.com', 'Dũng Trần Quang'),
(9, 'pbkdf2_sha256$1000000$7wUg8XgwFlMmKfg5CKNolZ$cRtqQkJYV5yHOQRjfSSAlvKIzPaDoUDbV6q/I6tcYNw=', NULL, 0, 'V009218', 'Dũng', 'Trần Quang', 'dung.tranquang@olympus.com', 0, 1, '2025-10-20 06:19:39.919574', 'staff', NULL, NULL, '', NULL, '', NULL),
(10, 'pbkdf2_sha256$1000000$G4HScB76tkwLkiODG0Wp50$woR9qn5exL7Vbdm4GR7aWGhqGNGzmaxkWXZ/Ah7k5KE=', NULL, 0, 'V000536', 'Vương', 'Nguyễn Văn', 'vuong.nguyenvan@olympus.com', 0, 1, '2025-10-21 13:11:29.326517', 'staff', NULL, NULL, '', NULL, '', NULL),
(11, 'pbkdf2_sha256$1000000$GuGdYCDxHdNdUUOT4qOXun$1k012yG4RhZJpzx81C3tuKzFWnQxGYPGl+aT5dxAlwA=', NULL, 0, 'V003305', 'Quang', 'Phạm Ngọc', 'quang.phamngoc@olympus.com', 0, 1, '2025-10-22 08:16:23.929890', 'staff', NULL, NULL, '', NULL, '', NULL);

DROP TABLE IF EXISTS `accounts_user_groups`;
CREATE TABLE `accounts_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_user_groups_user_id_group_id_59c0b32f_uniq` (`user_id`,`group_id`),
  KEY `accounts_user_groups_group_id_bd11a704_fk_auth_group_id` (`group_id`),
  CONSTRAINT `accounts_user_groups_group_id_bd11a704_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `accounts_user_groups_user_id_52b62117_fk_accounts_user_id` FOREIGN KEY (`user_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `accounts_user_user_permissions`;
CREATE TABLE `accounts_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `accounts_user_user_permi_user_id_permission_id_2ab516c2_uniq` (`user_id`,`permission_id`),
  KEY `accounts_user_user_p_permission_id_113bb443_fk_auth_perm` (`permission_id`),
  CONSTRAINT `accounts_user_user_p_permission_id_113bb443_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `accounts_user_user_p_user_id_e4f0a161_fk_accounts_` FOREIGN KEY (`user_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `auth_group`;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `auth_group_permissions`;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `auth_permission`;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `auth_permission` (`id`, `name`, `content_type_id`, `codename`) VALUES
(1, 'Can add log entry', 1, 'add_logentry'),
(2, 'Can change log entry', 1, 'change_logentry'),
(3, 'Can delete log entry', 1, 'delete_logentry'),
(4, 'Can view log entry', 1, 'view_logentry'),
(5, 'Can add permission', 2, 'add_permission'),
(6, 'Can change permission', 2, 'change_permission'),
(7, 'Can delete permission', 2, 'delete_permission'),
(8, 'Can view permission', 2, 'view_permission'),
(9, 'Can add group', 3, 'add_group'),
(10, 'Can change group', 3, 'change_group'),
(11, 'Can delete group', 3, 'delete_group'),
(12, 'Can view group', 3, 'view_group'),
(13, 'Can add content type', 4, 'add_contenttype'),
(14, 'Can change content type', 4, 'change_contenttype'),
(15, 'Can delete content type', 4, 'delete_contenttype'),
(16, 'Can view content type', 4, 'view_contenttype'),
(17, 'Can add session', 5, 'add_session'),
(18, 'Can change session', 5, 'change_session'),
(19, 'Can delete session', 5, 'delete_session'),
(20, 'Can view session', 5, 'view_session'),
(21, 'Can add user', 6, 'add_user'),
(22, 'Can change user', 6, 'change_user'),
(23, 'Can delete user', 6, 'delete_user'),
(24, 'Can view user', 6, 'view_user'),
(25, 'Can add Nhân viên', 7, 'add_employee'),
(26, 'Can change Nhân viên', 7, 'change_employee'),
(27, 'Can delete Nhân viên', 7, 'delete_employee'),
(28, 'Can view Nhân viên', 7, 'view_employee'),
(29, 'Can add Bộ phận', 8, 'add_department'),
(30, 'Can change Bộ phận', 8, 'change_department'),
(31, 'Can delete Bộ phận', 8, 'delete_department'),
(32, 'Can view Bộ phận', 8, 'view_department'),
(33, 'Can add Đơn đặt hàng', 9, 'add_purchaseorder'),
(34, 'Can change Đơn đặt hàng', 9, 'change_purchaseorder'),
(35, 'Can delete Đơn đặt hàng', 9, 'delete_purchaseorder'),
(36, 'Can view Đơn đặt hàng', 9, 'view_purchaseorder'),
(37, 'Can add Nhà cung cấp', 10, 'add_supplier'),
(38, 'Can change Nhà cung cấp', 10, 'change_supplier'),
(39, 'Can delete Nhà cung cấp', 10, 'delete_supplier'),
(40, 'Can view Nhà cung cấp', 10, 'view_supplier'),
(41, 'Can add Danh mục', 11, 'add_category'),
(42, 'Can change Danh mục', 11, 'change_category'),
(43, 'Can delete Danh mục', 11, 'delete_category'),
(44, 'Can view Danh mục', 11, 'view_category'),
(45, 'Can add Đơn vị tính', 12, 'add_unit'),
(46, 'Can change Đơn vị tính', 12, 'change_unit'),
(47, 'Can delete Đơn vị tính', 12, 'delete_unit'),
(48, 'Can view Đơn vị tính', 12, 'view_unit'),
(49, 'Can add Kho', 13, 'add_warehouse'),
(50, 'Can change Kho', 13, 'change_warehouse'),
(51, 'Can delete Kho', 13, 'delete_warehouse'),
(52, 'Can view Kho', 13, 'view_warehouse'),
(53, 'Can add Cột kho', 14, 'add_warehousecolumn'),
(54, 'Can change Cột kho', 14, 'change_warehousecolumn'),
(55, 'Can delete Cột kho', 14, 'delete_warehousecolumn'),
(56, 'Can view Cột kho', 14, 'view_warehousecolumn'),
(57, 'Can add Sản phẩm', 15, 'add_product'),
(58, 'Can change Sản phẩm', 15, 'change_product'),
(59, 'Can delete Sản phẩm', 15, 'delete_product'),
(60, 'Can view Sản phẩm', 15, 'view_product'),
(61, 'Can add Dãy kho', 16, 'add_warehouserow'),
(62, 'Can change Dãy kho', 16, 'change_warehouserow'),
(63, 'Can delete Dãy kho', 16, 'delete_warehouserow'),
(64, 'Can view Dãy kho', 16, 'view_warehouserow'),
(65, 'Can add Chi tiết đơn hàng', 17, 'add_purchaseorderitem'),
(66, 'Can change Chi tiết đơn hàng', 17, 'change_purchaseorderitem'),
(67, 'Can delete Chi tiết đơn hàng', 17, 'delete_purchaseorderitem'),
(68, 'Can view Chi tiết đơn hàng', 17, 'view_purchaseorderitem'),
(69, 'Can add Phiếu nhập kho', 18, 'add_stockreceipt'),
(70, 'Can change Phiếu nhập kho', 18, 'change_stockreceipt'),
(71, 'Can delete Phiếu nhập kho', 18, 'delete_stockreceipt'),
(72, 'Can view Phiếu nhập kho', 18, 'view_stockreceipt'),
(73, 'Can add Chi tiết phiếu nhập', 19, 'add_stockreceiptitem'),
(74, 'Can change Chi tiết phiếu nhập', 19, 'change_stockreceiptitem'),
(75, 'Can delete Chi tiết phiếu nhập', 19, 'delete_stockreceiptitem'),
(76, 'Can view Chi tiết phiếu nhập', 19, 'view_stockreceiptitem'),
(77, 'Can add Cấu hình Email', 20, 'add_emailconfiguration'),
(78, 'Can change Cấu hình Email', 20, 'change_emailconfiguration'),
(79, 'Can delete Cấu hình Email', 20, 'delete_emailconfiguration'),
(80, 'Can view Cấu hình Email', 20, 'view_emailconfiguration'),
(81, 'Can add Mẫu email', 21, 'add_emailtemplate'),
(82, 'Can change Mẫu email', 21, 'change_emailtemplate'),
(83, 'Can delete Mẫu email', 21, 'delete_emailtemplate'),
(84, 'Can view Mẫu email', 21, 'view_emailtemplate'),
(85, 'Can add attachment', 22, 'add_attachment'),
(86, 'Can change attachment', 22, 'change_attachment'),
(87, 'Can delete attachment', 22, 'delete_attachment'),
(88, 'Can view attachment', 22, 'view_attachment'),
(89, 'Can add Yêu cầu cấp phát', 23, 'add_inventoryrequest'),
(90, 'Can change Yêu cầu cấp phát', 23, 'change_inventoryrequest'),
(91, 'Can delete Yêu cầu cấp phát', 23, 'delete_inventoryrequest'),
(92, 'Can view Yêu cầu cấp phát', 23, 'view_inventoryrequest'),
(93, 'Can add Sản phẩm yêu cầu', 24, 'add_requestitem'),
(94, 'Can change Sản phẩm yêu cầu', 24, 'change_requestitem'),
(95, 'Can delete Sản phẩm yêu cầu', 24, 'delete_requestitem'),
(96, 'Can view Sản phẩm yêu cầu', 24, 'view_requestitem'),
(97, 'Can add Nhân viên cần cấp phát', 25, 'add_requestemployee'),
(98, 'Can change Nhân viên cần cấp phát', 25, 'change_requestemployee'),
(99, 'Can delete Nhân viên cần cấp phát', 25, 'delete_requestemployee'),
(100, 'Can view Nhân viên cần cấp phát', 25, 'view_requestemployee'),
(101, 'Can add Phân bổ sản phẩm cho nhân viên', 26, 'add_employeeproductrequest'),
(102, 'Can change Phân bổ sản phẩm cho nhân viên', 26, 'change_employeeproductrequest'),
(103, 'Can delete Phân bổ sản phẩm cho nhân viên', 26, 'delete_employeeproductrequest'),
(104, 'Can view Phân bổ sản phẩm cho nhân viên', 26, 'view_employeeproductrequest'),
(105, 'Can add Phiếu kiểm kê', 27, 'add_inventoryaudit'),
(106, 'Can change Phiếu kiểm kê', 27, 'change_inventoryaudit'),
(107, 'Can delete Phiếu kiểm kê', 27, 'delete_inventoryaudit'),
(108, 'Can view Phiếu kiểm kê', 27, 'view_inventoryaudit'),
(109, 'Can add Chi tiết kiểm kê', 28, 'add_inventoryaudititem'),
(110, 'Can change Chi tiết kiểm kê', 28, 'change_inventoryaudititem'),
(111, 'Can delete Chi tiết kiểm kê', 28, 'delete_inventoryaudititem'),
(112, 'Can view Chi tiết kiểm kê', 28, 'view_inventoryaudititem'),
(113, 'Can add Snapshot tồn kho tháng', 29, 'add_monthlyinventorysnapshot'),
(114, 'Can change Snapshot tồn kho tháng', 29, 'change_monthlyinventorysnapshot'),
(115, 'Can delete Snapshot tồn kho tháng', 29, 'delete_monthlyinventorysnapshot'),
(116, 'Can view Snapshot tồn kho tháng', 29, 'view_monthlyinventorysnapshot'),
(117, 'Can add Giao dịch kho', 30, 'add_stocktransaction'),
(118, 'Can change Giao dịch kho', 30, 'change_stocktransaction'),
(119, 'Can delete Giao dịch kho', 30, 'delete_stocktransaction'),
(120, 'Can view Giao dịch kho', 30, 'view_stocktransaction'),
(121, 'Can add Lịch sử Backup', 31, 'add_backuphistory'),
(122, 'Can change Lịch sử Backup', 31, 'change_backuphistory'),
(123, 'Can delete Lịch sử Backup', 31, 'delete_backuphistory'),
(124, 'Can view Lịch sử Backup', 31, 'view_backuphistory'),
(125, 'Can add Cấu hình Backup', 32, 'add_backupconfiguration'),
(126, 'Can change Cấu hình Backup', 32, 'change_backupconfiguration'),
(127, 'Can delete Cấu hình Backup', 32, 'delete_backupconfiguration'),
(128, 'Can view Cấu hình Backup', 32, 'view_backupconfiguration');

DROP TABLE IF EXISTS `backup_configuration`;
CREATE TABLE `backup_configuration` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `backup_frequency` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `backup_time` time(6) DEFAULT NULL,
  `include_database` tinyint(1) NOT NULL,
  `include_media` tinyint(1) NOT NULL,
  `max_backups_keep` int NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `last_backup_date` datetime(6) DEFAULT NULL,
  `last_backup_success` tinyint(1) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backup_configuration_created_by_id_68004916_fk_accounts_user_id` (`created_by_id`),
  KEY `backup_configuration_updated_by_id_89f9417d_fk_accounts_user_id` (`updated_by_id`),
  CONSTRAINT `backup_configuration_created_by_id_68004916_fk_accounts_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `backup_configuration_updated_by_id_89f9417d_fk_accounts_user_id` FOREIGN KEY (`updated_by_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `backup_configuration` (`id`, `backup_frequency`, `backup_time`, `include_database`, `include_media`, `max_backups_keep`, `is_active`, `last_backup_date`, `last_backup_success`, `created_at`, `updated_at`, `created_by_id`, `updated_by_id`) VALUES
(1, 'manual', NULL, 1, 1, 10, 1, '2025-10-22 09:33:17.117179', 1, '2025-10-22 09:29:14.307846', '2025-10-22 09:33:17.117179', 1, NULL);

DROP TABLE IF EXISTS `backup_history`;
CREATE TABLE `backup_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `backup_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `backup_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `backup_file` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file_size` bigint DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `error_message` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(6) NOT NULL,
  `is_auto` tinyint(1) NOT NULL,
  `restored_at` datetime(6) DEFAULT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `restored_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `backup_history_created_by_id_a35f9596_fk_accounts_user_id` (`created_by_id`),
  KEY `backup_history_restored_by_id_aecc48ad_fk_accounts_user_id` (`restored_by_id`),
  CONSTRAINT `backup_history_created_by_id_a35f9596_fk_accounts_user_id` FOREIGN KEY (`created_by_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `backup_history_restored_by_id_aecc48ad_fk_accounts_user_id` FOREIGN KEY (`restored_by_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `backup_history` (`id`, `backup_type`, `backup_name`, `backup_file`, `file_size`, `status`, `error_message`, `created_at`, `is_auto`, `restored_at`, `created_by_id`, `restored_by_id`) VALUES
(1, 'full', 'backup_full_20251022_092925.zip', 'backups/backup_full_20251022_092925_UtJV4Z2.zip', 210, 'success', NULL, '2025-10-22 09:29:25.145117', 0, NULL, 1, NULL),
(2, 'database', 'backup_database_20251022_092952.zip', 'backups/backup_database_20251022_092952_wRUZbcW.zip', 210, 'success', NULL, '2025-10-22 09:29:52.305196', 0, NULL, 1, NULL),
(3, 'database', 'backup_database_20251022_093127.zip', '', NULL, 'failed', '[WinError 2] The system cannot find the file specified', '2025-10-22 09:31:27.425522', 0, NULL, 1, NULL),
(4, 'database', 'backup_database_20251022_093144.zip', '', NULL, 'failed', '[WinError 2] The system cannot find the file specified', '2025-10-22 09:31:44.623472', 0, NULL, 1, NULL),
(5, 'database', 'backup_database_20251022_093234.zip', '', NULL, 'failed', '[WinError 2] The system cannot find the file specified', '2025-10-22 09:32:34.327184', 0, NULL, 1, NULL),
(6, 'full', 'backup_full_20251022_093241.zip', '', NULL, 'failed', '[WinError 2] The system cannot find the file specified', '2025-10-22 09:32:41.751177', 0, NULL, 1, NULL),
(7, 'media', 'backup_media_20251022_093317.zip', 'backups/backup_media_20251022_093317_QOd1ItG.zip', 22, 'success', NULL, '2025-10-22 09:33:17.100356', 0, NULL, 1, NULL),
(8, 'database', 'backup_database_20251022_093333.zip', '', NULL, 'pending', NULL, '2025-10-22 09:33:33.992856', 0, NULL, 1, NULL);

DROP TABLE IF EXISTS `django_admin_log`;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext COLLATE utf8mb4_unicode_ci,
  `object_repr` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_accounts_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_accounts_user_id` FOREIGN KEY (`user_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `django_content_type`;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `django_content_type` (`id`, `app_label`, `model`) VALUES
(6, 'accounts', 'user'),
(1, 'admin', 'logentry'),
(3, 'auth', 'group'),
(2, 'auth', 'permission'),
(4, 'contenttypes', 'contenttype'),
(22, 'django_summernote', 'attachment'),
(8, 'employees', 'department'),
(7, 'employees', 'employee'),
(11, 'inventory', 'category'),
(15, 'inventory', 'product'),
(18, 'inventory', 'stockreceipt'),
(19, 'inventory', 'stockreceiptitem'),
(30, 'inventory', 'stocktransaction'),
(12, 'inventory', 'unit'),
(13, 'inventory', 'warehouse'),
(14, 'inventory', 'warehousecolumn'),
(16, 'inventory', 'warehouserow'),
(26, 'inventory_requests', 'employeeproductrequest'),
(23, 'inventory_requests', 'inventoryrequest'),
(25, 'inventory_requests', 'requestemployee'),
(24, 'inventory_requests', 'requestitem'),
(27, 'reports', 'inventoryaudit'),
(28, 'reports', 'inventoryaudititem'),
(29, 'reports', 'monthlyinventorysnapshot'),
(5, 'sessions', 'session'),
(9, 'suppliers', 'purchaseorder'),
(17, 'suppliers', 'purchaseorderitem'),
(10, 'suppliers', 'supplier'),
(32, 'system_settings', 'backupconfiguration'),
(31, 'system_settings', 'backuphistory'),
(20, 'system_settings', 'emailconfiguration'),
(21, 'system_settings', 'emailtemplate');

DROP TABLE IF EXISTS `django_migrations`;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `django_migrations` (`id`, `app`, `name`, `applied`) VALUES
(1, 'contenttypes', '0001_initial', '2025-10-16 02:31:50.289962'),
(2, 'contenttypes', '0002_remove_content_type_name', '2025-10-16 02:31:50.394716'),
(3, 'auth', '0001_initial', '2025-10-16 02:31:50.649834'),
(4, 'auth', '0002_alter_permission_name_max_length', '2025-10-16 02:31:50.709396'),
(5, 'auth', '0003_alter_user_email_max_length', '2025-10-16 02:31:50.715885'),
(6, 'auth', '0004_alter_user_username_opts', '2025-10-16 02:31:50.724236'),
(7, 'auth', '0005_alter_user_last_login_null', '2025-10-16 02:31:50.730747'),
(8, 'auth', '0006_require_contenttypes_0002', '2025-10-16 02:31:50.734736'),
(9, 'auth', '0007_alter_validators_add_error_messages', '2025-10-16 02:31:50.744447'),
(10, 'auth', '0008_alter_user_username_max_length', '2025-10-16 02:31:50.751115'),
(11, 'auth', '0009_alter_user_last_name_max_length', '2025-10-16 02:31:50.758602'),
(12, 'auth', '0010_alter_group_name_max_length', '2025-10-16 02:31:50.776251'),
(13, 'auth', '0011_update_proxy_permissions', '2025-10-16 02:31:50.784428'),
(14, 'auth', '0012_alter_user_first_name_max_length', '2025-10-16 02:31:50.791147'),
(15, 'accounts', '0001_initial', '2025-10-16 02:31:51.111477'),
(16, 'admin', '0001_initial', '2025-10-16 02:31:51.409623'),
(17, 'admin', '0002_logentry_remove_auto_add', '2025-10-16 02:31:51.419547'),
(18, 'admin', '0003_logentry_add_action_flag_choices', '2025-10-16 02:31:51.430870'),
(19, 'sessions', '0001_initial', '2025-10-16 02:31:51.469225'),
(20, 'employees', '0001_initial', '2025-10-16 03:26:43.492760'),
(21, 'employees', 'custom_migration', '2025-10-16 04:44:16.839794'),
(22, 'suppliers', '0001_initial', '2025-10-16 05:01:39.961791'),
(23, 'inventory', '0001_initial', '2025-10-16 07:18:13.622546'),
(24, 'inventory', '0002_remove_product_purchase_order', '2025-10-16 08:24:36.473211'),
(26, 'inventory', '0003_stockreceipt_stockreceiptitem', '2025-10-16 08:41:06.124256'),
(27, 'inventory', '0002_remove_product_purchase_order_stockreceipt_and_more', '2025-10-17 08:38:56.071968'),
(28, 'suppliers', '0002_purchaseorderitem', '2025-10-17 08:38:56.074838'),
(29, 'inventory', '0003_stockreceiptitem_purchase_order_item_and_more', '2025-10-17 08:38:56.079822'),
(30, 'accounts', '0002_alter_user_options_user_manager_user_manager_email_and_more', '2025-10-17 08:39:13.556843'),
(31, 'system_settings', '0001_initial', '2025-10-18 01:33:59.252323'),
(32, 'system_settings', '0002_auto_20251018_0833', '2025-10-18 01:35:52.007045'),
(33, 'system_settings', '0003_emailconfiguration_auth_method_and_more', '2025-10-18 01:43:32.991798'),
(34, 'system_settings', '0004_emailtemplate', '2025-10-18 02:28:52.842424'),
(35, 'django_summernote', '0001_initial', '2025-10-18 02:34:57.836549'),
(36, 'django_summernote', '0002_update-help_text', '2025-10-18 02:34:57.848280'),
(37, 'inventory_requests', '0001_initial', '2025-10-18 03:06:45.561781'),
(38, 'inventory_requests', '0002_employeeproductrequest', '2025-10-18 04:06:03.691644'),
(39, 'accounts', '0003_alter_user_manager', '2025-10-18 06:53:19.668380'),
(40, 'inventory_requests', '0003_alter_inventoryrequest_scheduled_date', '2025-10-20 01:46:26.595687'),
(41, 'inventory_requests', '0004_inventoryrequest_scheduled_at', '2025-10-20 01:53:27.016803'),
(42, 'inventory_requests', '0005_inventoryrequest_schedule_notes', '2025-10-20 02:40:22.813664'),
(43, 'system_settings', '0005_emailconfiguration_from_name', '2025-10-20 06:32:07.793115'),
(44, 'reports', '0001_initial', '2025-10-20 08:42:34.979456'),
(45, 'inventory', '0004_stocktransaction', '2025-10-21 03:06:37.685119'),
(46, 'system_settings', '0006_emailtemplate_default_cc_and_more', '2025-10-21 15:07:28.039112'),
(47, 'django_summernote', '0003_alter_attachment_id', '2025-10-21 15:42:03.373179'),
(48, 'system_settings', '0007_alter_emailtemplate_type', '2025-10-21 15:42:03.373179'),
(49, 'system_settings', '0008_backupconfiguration_backuphistory', '2025-10-22 09:27:40.470292');

DROP TABLE IF EXISTS `django_session`;
CREATE TABLE `django_session` (
  `session_key` varchar(40) COLLATE utf8mb4_unicode_ci NOT NULL,
  `session_data` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `django_session` (`session_key`, `session_data`, `expire_date`) VALUES
('0try1lji8cmhehzwobpl1k83ufsz09j9', '.eJzFUU1P3DAQ_SuWz6tl7DiJN8f20FaCqhIICQGKHHvYuGXtJbGFltX-d5wQoiB66am3eN7HvDc50lrF0Naxx662hlZU0tVy1ij9B90AmN_Kbf1aexc626wHynpC-_WFN_j4ZeJ-MGhV3yZ1XjZ5wZhU2jSZLAUqkQksJDRCltBwXQohuVFYCJUXfPMAiA-ZybQxEiSIZGr7PqKpjQqKVkfa4VPEPoyphVzNb52ipIU3X3nOAEAMhSYMuwR893cRAMGSn9t4uIsMde7IVTt-NYn8rDpsfQpf75RT21F0bUe4DCSJGQPrWnKe7pHo2u_2jxjekg2bOTtjcMaB54QVFS-G6AF3Pa1ujxQT2R8Q32NeA9tssjxxZsSp3YD8LR2Zwy8FBvchCX5cpeG-8ybq-QoAfDGcnAcLzfxUZXA2mduSX-MSzPXiYKZ-isoFGw60YvMvWMxOq__QKfvc6Zt9MzmQ3r4gufynDven0yt38_7n:1vB8dQ:E6q_EiAHp7g3PAAZo89lvvbj8qAnzBm-4s604OIqqHw', '2025-11-04 16:26:28.191337'),
('2pqn7tnuace4vn5yzwro3sas8tnej30j', '.eJxVjEEOwiAQRe_C2pCBQkGX7nsGwsyAVA0kpV0Z765NutDtf-_9lwhxW0vYelrCzOIilDj9bhjpkeoO-B7rrUlqdV1mlLsiD9rl1Dg9r4f7d1BiL986s3ca09l4pEHZnMCzRdLOAJrBMSFo7QEQLWgwmUYbiZFHRRa1G8T7A-6rOBM:1vBORA:p43Og7XC_PcuR4Z5FTTY_lCC_fGKvIjz0CYayR7szoU', '2025-11-05 09:18:52.443497'),
('8f688a4p2nxh3ah2cc4l1fpxmkzh7ldx', '.eJxVjMsOwiAQAP-FsyHAUigevfcbGthdpGog6eNk_HdD0oNeZybzFnM89jIfG6_zQuIqjLj8shTxybULesR6bxJb3dclyZ7I025yasSv29n-DUrcSt8aBOuddtqjs3lU4MD7gBqRB7akE49MQRNZZVQEm0PGISeg6LQCEJ8vx8E3mg:1v9vWb:KYS46UkW65KAdy9wUuyEY25n6KXq7_Iv5suo5xPXs_c', '2025-11-01 01:14:25.368810'),
('bs10d8pbxo7pes16rs8cv3sv2wpx3v9l', '.eJxVjDsOwjAQRO_iGlmWN_5R0nOGaNe7wQFkS_lUEXcnkVJAN5r3ZjbV47qUfp1l6kdWV2XV5bcjzC-pB-An1kfTudVlGkkfij7prO-N5X073b-DgnPZ1-SyzzahdDTAwBGtQcw-mtBBTMbvmYgTBHIsDGijA4ksARNYh6A-XwcYOJI:1vB4CO:YK-WVzfBFHeaivR8t5KqWXN5gStXv6xzewHe2HADr4M', '2025-11-04 04:42:16.259135'),
('g97dhy0n7eqlh2ljwkzezdb3twpplvhk', '.eJxVjMEOwiAQRP-FsyFbWKF69N5vIAu7SNXQpLQn47_bJj3obTLvzbxVoHUpYW0yh5HVVXl1-u0ipafUHfCD6n3SaarLPEa9K_qgTQ8Ty-t2uH8HhVrZ1pIiUiaDvQhn5yNdOiuWhMCfMQFQBAabzBZ74JgcOrRddhYFDZD6fAEXfThk:1vA1Kh:Z7ZGT8skr1_77vVj7KNtrygRjrx1EQZeuv5tzwNElwc', '2025-11-01 07:26:31.333962'),
('hb7ngqq7j6xreberq47k49rwn87ag0ox', '.eJxVjDsOwjAQRO_iGlmWN_5R0nOGaNe7wQFkS_lUEXcnkVJAN5r3ZjbV47qUfp1l6kdWV2XV5bcjzC-pB-An1kfTudVlGkkfij7prO-N5X073b-DgnPZ1-SyzzahdDTAwBGtQcw-mtBBTMbvmYgTBHIsDGijA4ksARNYh6A-XwcYOJI:1vAl9i:o3UFvrtO7w5XTtH2Vlkx8GBc3UbOCJZh66voIbZVdGU', '2025-11-03 08:22:14.523409'),
('ixx5u608kqljcokfota9vo47o68nx4vq', '.eJxVjEEOwiAQRe_C2hAGEMSle89AZoapVA1NSrsy3l2bdKHb_977L5VxXWpeu8x5LOqsojr8boT8kLaBcsd2mzRPbZlH0puid9r1dSryvOzu30HFXr-18TZyQfJHSWzAoEMfU0Lkwhy9cLIgAcQOJTiHkCAQWQenEJACDOr9AfRsOB4:1vB5bT:TGRRLluN49CpsxPMq6pD-0FzAVOEJrBlz1E4BXzjh9Y', '2025-11-04 13:12:15.122339'),
('roiln2goeqa8pnupvmslwi004wb7g9n7', '.eJxVjEEOwiAQRe_C2pCBQkGX7nsGwsyAVA0kpV0Z765NutDtf-_9lwhxW0vYelrCzOIilDj9bhjpkeoO-B7rrUlqdV1mlLsiD9rl1Dg9r4f7d1BiL986s3ca09l4pEHZnMCzRdLOAJrBMSFo7QEQLWgwmUYbiZFHRRa1G8T7A-6rOBM:1vB4Dk:cAqU5hnaVDC59YJUk0YC_qkXXCT0QAJl3aX4_QSCj40', '2025-11-04 04:43:40.134644'),
('rqxr78sicni8cgx9j29fy5movyjqmo9e', '.eJxVjMEKwyAQRP_FcxESo6s99t5vkNVda9qiEJNT6L_XQA4tzGnem9mFx23Nfmu8-JnEVQzi8tsFjC8uB6AnlkeVsZZ1mYM8FHnSJu-V-H073b-DjC33dTQOwqCdQYdkHSqmNOlEhhlA25AMRk4T9AAqAyODVqztSJPFzsXnC_8eOGk:1v9FWn:cSlDLsIc5DKQGLaw5Yi5aIadgTDL6thQhEb3rHuiiJM', '2025-10-30 04:23:49.466324'),
('sayxf7ljf9ve9wv8p564v2cvznbs26kc', '.eJzFkkFv2zAMhf-KoHOQUrJsa76tO_TS7tKiwLAOBi0xsbZYTm0ZRRbkv09KUzdF0duwXQyJ75n8HqE9r3EKbT2NNNTO8oprvjivNWh-kU-C_Yl-3S9N78PgmmWyLE_quLzpLW0uT943DVoc2_h3XjZ5IYRGY5tMl4pQZYoKDY3SJTTSlEppaZEKhXkhP62AaJXZzFirQYOKTd04TmRriwF5tecDPU40hiO1kov5biJKHPjti8wFACjJZ42GKFxjx-6Gh0kQlp7dtelkmmh6woHaPkLXHXpcH8337iiXgT1MIAQ437LruIdoN3233VB4JkoTJVwIuJAgcwa6kmmRLlA38ur7nlM09zuiF7x7gCyXiW1WPHZJec8WJ3bnRkvbEI1Xn2NxO_R2MnPqGFicVU8tLyM8rDCwxrHQunQj9GzTH4O8LMfWjxP64MKOV2Je91ntsPiHObL3Ma6eyWHHRveb2O1fYC-yDD5gB9FA-qLw69cIN-kFfF1Pu9O7-G95fhwOfwDwOjuP:1vAlG7:TdMm1cWaLH-BHw2ATIrXgsYS-78howW85F_KgtY_SeY', '2025-11-03 08:28:51.654597'),
('sq4lfy5cd8fzp23r0cu3tzcv5txluzhz', '.eJxVjMsOwiAQAP-FsyHAUigevfcbGthdpGog6eNk_HdD0oNeZybzFnM89jIfG6_zQuIqjLj8shTxybULesR6bxJb3dclyZ7I025yasSv29n-DUrcSt8aBOuddtqjs3lU4MD7gBqRB7akE49MQRNZZVQEm0PGISeg6LQCEJ8vx8E3mg:1v9gSM:cKwAsmiR52Y-WV_0EdVDxo0lvQ_b4A0y8QKgUxJkmFU', '2025-10-31 09:09:02.006777'),
('vyodset1h756x3gibr8gnfi5fzvlez9r', '.eJxVjEEOwiAQRe_C2pCBQkGX7nsGwsyAVA0kpV0Z765NutDtf-_9lwhxW0vYelrCzOIilDj9bhjpkeoO-B7rrUlqdV1mlLsiD9rl1Dg9r4f7d1BiL986s3ca09l4pEHZnMCzRdLOAJrBMSFo7QEQLWgwmUYbiZFHRRa1G8T7A-6rOBM:1vB5We:OuGlnUM5SS7iHtCXvA7nY5mTtWYQ5Y3r1VqApPCDDV4', '2025-11-04 13:07:16.224897'),
('y6wwunjwhhs85czbgptzsl2dp0vvf3no', '.eJxVjEEOwiAQRe_C2pCBQkGX7nsGwsyAVA0kpV0Z765NutDtf-_9lwhxW0vYelrCzOIilDj9bhjpkeoO-B7rrUlqdV1mlLsiD9rl1Dg9r4f7d1BiL986s3ca09l4pEHZnMCzRdLOAJrBMSFo7QEQLWgwmUYbiZFHRRa1G8T7A-6rOBM:1vB4JB:aysXyK4tFpaw9LUCrXcnCPW8gdAY-MX2dEhwOL5MPKQ', '2025-11-04 11:49:17.094415');

DROP TABLE IF EXISTS `django_summernote_attachment`;
CREATE TABLE `django_summernote_attachment` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `file` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploaded` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `employees_department`;
CREATE TABLE `employees_department` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `employees_department` (`id`, `code`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'IT', 'Công nghệ thông tin', '', '2025-10-16 04:41:39.700905', '2025-10-16 04:41:39.700905'),
(2, 'GA', 'GA', 'GA', '2025-10-18 06:55:10.541290', '2025-10-18 06:55:10.541290');

DROP TABLE IF EXISTS `employees_employee`;
CREATE TABLE `employees_employee` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `employee_id` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `first_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `full_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(1) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_card` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_number` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` longtext COLLATE utf8mb4_unicode_ci,
  `position` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `join_date` date DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `department_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employee_id` (`employee_id`),
  KEY `employees_employee_department_id_410c23c8_fk_employees` (`department_id`),
  CONSTRAINT `employees_employee_department_id_410c23c8_fk_employees` FOREIGN KEY (`department_id`) REFERENCES `employees_department` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `employees_employee` (`id`, `employee_id`, `first_name`, `last_name`, `full_name`, `date_of_birth`, `gender`, `id_card`, `phone_number`, `email`, `address`, `position`, `join_date`, `status`, `created_at`, `updated_at`, `department_id`) VALUES
(1, 'V018283', 'Đinh', 'Lang Việt', 'Lang Việt Đinh', NULL, 'M', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2025-10-16 04:44:58.723521', '2025-10-16 04:44:58.723521', 1),
(2, 'V019935', 'Hoài', 'Nguyễn Thị', 'Nguyễn Thị Hoài', NULL, 'M', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2025-10-18 04:14:36.172266', '2025-10-18 04:14:36.172266', 1),
(3, 'V003522', 'Lam', 'Trần Thị', 'Trần Thị Lam', NULL, 'M', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2025-10-18 06:55:22.052536', '2025-10-18 06:55:22.052536', 2),
(4, 'V006330', 'Nguyệt', 'Trương Thị Minh', 'Trương Thị Minh Nguyệt', NULL, 'M', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2025-10-18 06:55:54.601590', '2025-10-18 06:55:54.601590', 2),
(5, 'V011755', 'Ly', 'Nguyễn Thị Mai', 'Nguyễn Thị Mai Ly', NULL, 'M', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2025-10-18 07:20:28.503770', '2025-10-18 07:20:28.503770', 2),
(6, 'V014554', 'Nhành', 'Nguyễn Thị', 'Nguyễn Thị Nhành', NULL, 'M', NULL, NULL, NULL, NULL, NULL, NULL, 1, '2025-10-18 07:20:49.525932', '2025-10-18 07:20:49.525932', 2);

DROP TABLE IF EXISTS `inventory_category`;
CREATE TABLE `inventory_category` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_category` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Đồng phục', '', '2025-10-16 07:25:01.763754', '2025-10-16 07:25:01.763754'),
(2, 'Mực In', '', '2025-10-16 07:25:07.319210', '2025-10-16 07:25:07.319210'),
(3, 'văn phòng phẩm', '', '2025-10-17 08:06:11.211854', '2025-10-17 08:06:11.211854');

DROP TABLE IF EXISTS `inventory_product`;
CREATE TABLE `inventory_product` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `product_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_quantity` int unsigned NOT NULL,
  `minimum_quantity` int unsigned NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `category_id` bigint DEFAULT NULL,
  `unit_id` bigint DEFAULT NULL,
  `column_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_code` (`product_code`),
  KEY `inventory_product_category_id_c907876e_fk_inventory_category_id` (`category_id`),
  KEY `inventory_product_unit_id_be442e64_fk_inventory_unit_id` (`unit_id`),
  KEY `inventory_product_column_id_dedce630_fk_inventory` (`column_id`),
  CONSTRAINT `inventory_product_category_id_c907876e_fk_inventory_category_id` FOREIGN KEY (`category_id`) REFERENCES `inventory_category` (`id`),
  CONSTRAINT `inventory_product_column_id_dedce630_fk_inventory` FOREIGN KEY (`column_id`) REFERENCES `inventory_warehousecolumn` (`id`),
  CONSTRAINT `inventory_product_unit_id_be442e64_fk_inventory_unit_id` FOREIGN KEY (`unit_id`) REFERENCES `inventory_unit` (`id`),
  CONSTRAINT `inventory_product_chk_1` CHECK ((`current_quantity` >= 0)),
  CONSTRAINT `inventory_product_chk_2` CHECK ((`minimum_quantity` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_product` (`id`, `product_code`, `name`, `current_quantity`, `minimum_quantity`, `description`, `created_at`, `updated_at`, `category_id`, `unit_id`, `column_id`) VALUES
(1, '87867', 'quần đòng lục', 239, 10, '', '2025-10-16 07:34:57.625694', '2025-10-20 07:24:12.115744', 1, 2, 1),
(2, '4234324', 'mực in', 22, 5, '', '2025-10-17 05:57:51.958741', '2025-10-20 07:24:12.196573', 2, 1, 2),
(3, '0001', 'Bút bi thiên long', 5, 10, '', '2025-10-17 08:06:34.330574', '2025-10-20 08:28:50.365874', 3, 1, 1),
(4, '002', 'Áo Đồng Phục', 97, 10, '', '2025-10-18 07:19:16.686312', '2025-10-21 16:26:27.331725', 1, 1, 2),
(5, '003', 'Giày size S', 94, 10, '', '2025-10-18 07:19:43.542858', '2025-10-21 16:26:27.337730', 1, 2, 2);

DROP TABLE IF EXISTS `inventory_requests_employeeproductrequest`;
CREATE TABLE `inventory_requests_employeeproductrequest` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` int unsigned NOT NULL,
  `approved_quantity` int unsigned DEFAULT NULL,
  `issued_quantity` int unsigned NOT NULL,
  `notes` longtext COLLATE utf8mb4_unicode_ci,
  `employee_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  `request_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_requests_emplo_request_id_employee_id_p_d39ef1c6_uniq` (`request_id`,`employee_id`,`product_id`),
  KEY `inventory_requests_e_employee_id_0d886187_fk_employees` (`employee_id`),
  KEY `inventory_requests_e_product_id_691f4d5f_fk_inventory` (`product_id`),
  CONSTRAINT `inventory_requests_e_employee_id_0d886187_fk_employees` FOREIGN KEY (`employee_id`) REFERENCES `employees_employee` (`id`),
  CONSTRAINT `inventory_requests_e_product_id_691f4d5f_fk_inventory` FOREIGN KEY (`product_id`) REFERENCES `inventory_product` (`id`),
  CONSTRAINT `inventory_requests_e_request_id_d56bc7a6_fk_inventory` FOREIGN KEY (`request_id`) REFERENCES `inventory_requests_inventoryrequest` (`id`),
  CONSTRAINT `inventory_requests_employeeproductrequest_chk_1` CHECK ((`quantity` >= 0)),
  CONSTRAINT `inventory_requests_employeeproductrequest_chk_2` CHECK ((`approved_quantity` >= 0)),
  CONSTRAINT `inventory_requests_employeeproductrequest_chk_3` CHECK ((`issued_quantity` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_requests_employeeproductrequest` (`id`, `quantity`, `approved_quantity`, `issued_quantity`, `notes`, `employee_id`, `product_id`, `request_id`) VALUES
(1, 1, 1, 0, '', 1, 3, 7),
(2, 1, 1, 0, '', 1, 3, 8),
(3, 2, 2, 0, '', 2, 2, 9),
(4, 1, 1, 0, '', 1, 3, 10),
(5, 1, 1, 0, '', 1, 2, 11),
(6, 1, 1, 0, '', 1, 3, 12),
(7, 1, 1, 0, '', 2, 2, 12),
(8, 1, 1, 0, '', 1, 3, 13),
(9, 1, 1, 0, '', 1, 2, 13),
(10, 1, 1, 0, '', 1, 1, 13),
(11, 1, 1, 0, '', 2, 1, 13),
(12, 1, 1, 1, '', 2, 1, 14),
(13, 1, 1, 1, '', 2, 2, 14),
(14, 1, 1, 0, '', 2, 1, 15),
(15, 1, 1, 0, '', 2, 2, 15),
(16, 1, 1, 0, '', 2, 1, 16),
(17, 1, 1, 0, '', 2, 2, 16),
(18, 1, 1, 0, '', 2, 3, 17),
(19, 1, 1, 0, '', 2, 1, 17),
(20, 1, 1, 0, '', 2, 2, 17),
(21, 1, 1, 0, '', 2, 3, 18),
(22, 1, 1, 0, '', 2, 2, 18),
(23, 1, 1, 0, '', 2, 1, 18),
(24, 1, 1, 0, '', 2, 3, 19),
(25, 1, 1, 0, '', 2, 2, 19),
(26, 1, 1, 0, '', 2, 1, 19),
(27, 1, 1, 0, '', 1, 3, 19),
(28, 1, 1, 0, 'cấp mới', 3, 3, 20),
(29, 1, 1, 0, '', 3, 2, 20),
(30, 1, 1, 0, '', 4, 1, 20),
(31, 1, 1, 0, '', 4, 2, 20),
(32, 1, 1, 0, 'cấp mới đi', 3, 3, 21),
(33, 1, 1, 0, '', 3, 1, 21),
(34, 1, 1, 0, '', 4, 2, 21),
(35, 1, 1, 0, '', 2, 1, 21),
(36, 1, 1, 0, '', 2, 3, 22),
(37, 1, 1, 0, '', 3, 2, 22),
(38, 1, 1, 0, '', 4, 1, 22),
(39, 1, 1, 0, '', 1, 2, 22),
(40, 1, 1, 0, '', 3, 1, 23),
(41, 1, 1, 0, '', 3, 2, 23),
(42, 1, 1, 0, '', 4, 2, 23),
(43, 1, 1, 0, 'good', 6, 1, 24),
(44, 1, 1, 0, 'ok', 6, 5, 24),
(45, 1, 1, 0, '', 5, 5, 24),
(46, 1, 1, 0, 'loại tốt', 6, 5, 25),
(47, 1, 1, 0, '', 6, 4, 25),
(48, 1, 1, 0, '', 5, 5, 25),
(49, 1, 1, 0, '111', 2, 5, 26),
(50, 1, 1, 0, '', 5, 5, 26),
(51, 1, 1, 0, '', 4, 1, 26),
(52, 1, 1, 1, '', 2, 2, 27),
(53, 1, 1, 1, '', 2, 1, 27),
(54, 1, 1, 1, '', 2, 5, 28),
(55, 1, 1, 1, '', 2, 1, 28),
(56, 1, 1, 1, '', 2, 3, 28),
(57, 1, 1, 1, '', 2, 4, 28),
(58, 1, 1, 0, '', 1, 5, 29),
(59, 1, 1, 0, '', 2, 3, 29),
(60, 1, 1, 0, '', 2, 2, 29),
(61, 1, 1, 0, '', 2, 3, 30),
(62, 1, 1, 0, '', 1, 5, 30),
(63, 1, 1, 0, '', 2, 3, 31),
(64, 1, 1, 0, '', 1, 5, 31),
(65, 1, 1, 0, '', 5, 2, 31),
(66, 1, 1, 1, '', 2, 2, 32),
(67, 11111, 11111, 0, '', 5, 2, 33),
(68, 11111, 11111, 0, '', 3, 2, 33),
(69, 1, 1, 0, '', 2, 3, 34),
(70, 1, 1, 0, '', 5, 5, 34),
(71, 1, 1, 0, '', 2, 2, 34),
(72, 1, 1, 1, '', 2, 3, 35),
(73, 1, 1, 1, '', 6, 5, 35),
(74, 1, 1, 0, '', 1, 4, 36),
(75, 1, 1, 0, '', 1, 5, 36),
(76, 1, 1, 0, '', 2, 1, 37),
(77, 1, 1, 1, '', 3, 4, 38),
(78, 1, 1, 1, '', 3, 5, 38),
(79, 1, 1, 1, '', 3, 3, 38),
(80, 1, 1, 0, '', 2, 3, 39),
(81, 1, 1, 0, '', 2, 2, 39),
(82, 1, 1, 0, '', 2, 5, 39),
(83, 1, 1, 0, '', 2, 1, 39),
(84, 1, 1, 0, '', 2, 3, 40),
(85, 1, 1, 0, '', 2, 4, 40),
(86, 1, 1, 0, '', 2, 1, 40),
(87, 1, 1, 0, '', 2, 3, 41),
(88, 1, 1, 0, '', 5, 1, 41),
(89, 1, 1, 0, '', 4, 2, 41),
(90, 1, 1, 1, '', 3, 5, 42),
(91, 1, 1, 1, '', 3, 3, 42),
(92, 1, 1, 1, '', 4, 5, 42),
(93, 1, 1, 0, '', 1, 5, 44),
(94, 1, 1, 0, '', 1, 3, 44),
(95, 1, 1, 0, '', 1, 4, 47),
(96, 1, 1, 0, '', 1, 5, 47),
(97, 1, 1, 0, '', 1, 2, 47),
(98, 1, 1, 1, '', 2, 5, 48),
(99, 1, 1, 1, '', 2, 4, 48),
(100, 1, 1, 0, '', 1, 4, 49),
(101, 1, 1, 0, '', 1, 3, 49),
(102, 1, 1, 0, '', 1, 5, 49);

DROP TABLE IF EXISTS `inventory_requests_inventoryrequest`;
CREATE TABLE `inventory_requests_inventoryrequest` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `request_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `expected_date` date DEFAULT NULL,
  `scheduled_date` datetime(6) DEFAULT NULL,
  `completed_date` datetime(6) DEFAULT NULL,
  `approval_date` datetime(6) DEFAULT NULL,
  `approval_note` longtext COLLATE utf8mb4_unicode_ci,
  `rejection_reason` longtext COLLATE utf8mb4_unicode_ci,
  `notes` longtext COLLATE utf8mb4_unicode_ci,
  `approver_id` bigint DEFAULT NULL,
  `requester_id` bigint NOT NULL,
  `warehouse_manager_id` bigint DEFAULT NULL,
  `scheduled_at` datetime(6) DEFAULT NULL,
  `schedule_notes` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_code` (`request_code`),
  KEY `inventory_requests_i_approver_id_22ed7462_fk_accounts_` (`approver_id`),
  KEY `inventory_requests_i_requester_id_f0b71a9f_fk_accounts_` (`requester_id`),
  KEY `inventory_requests_i_warehouse_manager_id_716b079c_fk_accounts_` (`warehouse_manager_id`),
  CONSTRAINT `inventory_requests_i_approver_id_22ed7462_fk_accounts_` FOREIGN KEY (`approver_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `inventory_requests_i_requester_id_f0b71a9f_fk_accounts_` FOREIGN KEY (`requester_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `inventory_requests_i_warehouse_manager_id_716b079c_fk_accounts_` FOREIGN KEY (`warehouse_manager_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_requests_inventoryrequest` (`id`, `request_code`, `title`, `description`, `status`, `created_at`, `updated_at`, `expected_date`, `scheduled_date`, `completed_date`, `approval_date`, `approval_note`, `rejection_reason`, `notes`, `approver_id`, `requester_id`, `warehouse_manager_id`, `scheduled_at`, `schedule_notes`) VALUES
(4, 'YC25100001', 'test', '', 'draft', '2025-10-18 04:37:32.650766', '2025-10-18 04:37:32.650766', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 1, NULL, NULL, NULL),
(5, 'YC25100005', 'test', '', 'draft', '2025-10-18 04:38:24.891668', '2025-10-18 04:38:24.891668', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 1, NULL, NULL, NULL),
(6, 'YC25100006', 'test', '', 'draft', '2025-10-18 04:39:17.001539', '2025-10-18 04:39:17.001539', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 1, NULL, NULL, NULL),
(7, 'YC25100007', 'u56u56u65', '', 'draft', '2025-10-18 04:39:35.572613', '2025-10-18 04:39:35.572613', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 1, NULL, NULL, NULL),
(8, 'YC25100008', 'test', 'têtwe', 'draft', '2025-10-18 04:53:49.319964', '2025-10-18 04:53:49.319964', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 1, NULL, NULL, NULL),
(9, 'YC25100009', '12321321321', '321312', 'pending', '2025-10-18 04:58:27.477619', '2025-10-18 04:58:27.480759', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 1, NULL, NULL, NULL),
(10, 'YC25100010', 'tet4543543', '54543', 'draft', '2025-10-18 04:59:00.255735', '2025-10-18 05:03:33.334086', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 1, NULL, NULL, NULL),
(11, 'YC25100011', '43435534', 'thử cái xem thế nào', 'draft', '2025-10-18 05:54:37.241950', '2025-10-18 05:54:37.241950', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 1, NULL, NULL, NULL),
(12, 'YC25100012', 'lần này nữa', 'lần này nữa', 'draft', '2025-10-18 06:03:25.019830', '2025-10-18 06:03:25.019830', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 1, NULL, NULL, NULL),
(13, 'YC25100013', '4243432', '423423', 'draft', '2025-10-18 06:03:54.406199', '2025-10-18 06:03:54.406199', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 1, NULL, NULL, NULL),
(14, 'YC25100014', 'cấp phát đồng phục', 'cấp phát đồng phục', 'completed', '2025-10-18 06:19:49.518857', '2025-10-20 07:24:12.200470', '2025-10-18', '2025-10-22 23:50:00', '2025-10-20 07:24:12.200470', '2025-10-20 01:17:13.762699', '', NULL, '', 7, 2, 8, NULL, NULL),
(15, 'YC25100015', 'cấp phát đồng phục', 'cấp phát đồng phục', 'rejected', '2025-10-18 06:21:38.280231', '2025-10-18 09:19:52.554519', '2025-10-18', NULL, NULL, '2025-10-18 09:19:52.554519', NULL, 'thửu cái xem sao', '', 7, 2, NULL, NULL, NULL),
(16, 'YC25100016', 'cấp phát đồng phục', 'cấp phát đồng phục', 'rejected', '2025-10-18 06:22:01.768219', '2025-10-18 08:26:31.159008', '2025-10-18', NULL, NULL, '2025-10-18 08:26:31.159008', NULL, 'khoogn được đâu', '', 7, 2, NULL, NULL, NULL),
(17, 'YC25100017', 'cáp phát giày', '', 'scheduled', '2025-10-18 06:23:21.259131', '2025-10-20 02:41:05.630551', '2025-10-18', '2025-10-23 12:42:00', NULL, '2025-10-18 08:15:00.842597', '', NULL, '', 7, 2, 8, '2025-10-20 02:41:05.628946', NULL),
(18, 'YC25100018', 'cấp ơhats giầy', 'werwe', 'rejected', '2025-10-18 06:29:11.704152', '2025-10-18 08:23:19.197330', '2025-10-18', NULL, NULL, '2025-10-18 08:23:19.197330', NULL, 'khoogn đợc', '', 7, 2, NULL, NULL, NULL),
(19, 'YC25100019', 'cấp phát đồ', '', 'scheduled', '2025-10-18 06:38:52.460642', '2025-10-20 02:47:36.137466', '2025-10-18', '2025-10-29 12:48:00', NULL, '2025-10-18 08:09:59.710649', '', NULL, '', 7, 2, 8, '2025-10-20 02:47:36.137466', NULL),
(20, 'YC25100020', 'Cấp phát đồ', 'Cấp phát đồ', 'draft', '2025-10-18 06:56:35.220961', '2025-10-18 06:57:10.716448', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 1, NULL, NULL, NULL),
(21, 'YC25100021', 'Cáp phát đồ', 'Cấp phát đồ', 'pending', '2025-10-18 06:59:11.867336', '2025-10-18 06:59:11.917052', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 3, NULL, NULL, NULL),
(22, 'YC25100022', 'thửu cái nữa xem sao', '', 'scheduled', '2025-10-18 07:03:03.649129', '2025-10-20 02:50:39.136580', '2025-10-18', '2025-10-29 13:53:00', NULL, '2025-10-18 08:00:27.388964', '', NULL, '', 7, 2, 8, '2025-10-20 02:50:39.136580', NULL),
(23, 'YC25100023', 'cấp phát mới', '', 'pending', '2025-10-18 07:05:07.315104', '2025-10-18 07:05:07.350193', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 3, NULL, NULL, NULL),
(24, 'YC25100024', 'cấp phát đồng phục', '', 'draft', '2025-10-18 07:21:44.355280', '2025-10-18 07:21:44.355280', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 5, NULL, NULL, NULL),
(25, 'YC25100025', 'cáp phát đồng phục', 'cáp phát đồng phục', 'pending', '2025-10-18 07:22:41.358724', '2025-10-18 07:22:41.379397', '2025-10-18', NULL, NULL, NULL, NULL, NULL, '', NULL, 5, NULL, NULL, NULL),
(26, 'YC25100026', 'cấp phát giày', '', 'scheduled', '2025-10-18 07:25:46.401662', '2025-10-20 04:36:49.323522', '2025-10-18', '2025-10-21 08:00:00', NULL, '2025-10-18 07:35:22.023088', '', NULL, '', 7, 2, 8, '2025-10-20 04:36:49.323522', NULL),
(27, 'YC25100027', 'thử ngày mới', '', 'completed', '2025-10-20 01:23:44.221885', '2025-10-20 07:14:24.277969', '2025-10-20', '2025-10-29 00:00:00', '2025-10-20 07:14:24.277969', '2025-10-20 01:24:24.929003', '', NULL, '', 7, 2, 8, NULL, NULL),
(28, 'YC25100028', 'thử cái mới xem sao', 'test thử cái này', 'completed', '2025-10-20 03:01:49.926229', '2025-10-20 04:59:24.689487', '2025-10-20', '2025-10-28 15:37:00', '2025-10-20 04:59:24.689487', '2025-10-20 03:08:13.775069', '', NULL, '', 7, 2, 8, '2025-10-20 04:33:24.723574', NULL),
(29, 'YC25100029', '3123213', '321321', 'draft', '2025-10-20 03:04:32.258515', '2025-10-20 03:04:32.258515', '2025-10-20', NULL, NULL, NULL, NULL, NULL, '', NULL, 7, NULL, NULL, NULL),
(30, 'YC25100030', '13442342343', '423423', 'pending', '2025-10-20 03:05:13.153615', '2025-10-20 03:05:13.169535', '2025-10-20', NULL, NULL, NULL, NULL, NULL, '', NULL, 7, NULL, NULL, NULL),
(31, 'YC25100031', 'nhận đồng phục', '1234567', 'rejected', '2025-10-20 03:16:28.675953', '2025-10-20 03:19:40.780990', '2025-10-20', NULL, NULL, '2025-10-20 03:19:40.780990', NULL, 'khoogn được', '', 7, 2, NULL, NULL, NULL),
(32, 'YC25100032', 'thửu cái nữa', 'thửu cái nữa', 'completed', '2025-10-20 03:17:08.499471', '2025-10-20 04:57:36.951912', '2025-10-20', '2025-10-30 13:34:00', '2025-10-20 04:57:36.951912', '2025-10-20 03:19:33.490565', '', NULL, '', 7, 2, 8, '2025-10-20 04:32:54.170471', NULL),
(33, 'YC25100033', '321312312', '312321', 'approved', '2025-10-20 04:21:25.877220', '2025-10-20 04:21:44.738999', '2025-10-20', NULL, NULL, '2025-10-20 04:21:44.738999', '', NULL, '', 7, 2, NULL, NULL, NULL),
(34, 'YC25100034', 'cấp phát đồ', 'cấp phát đồ', 'pending', '2025-10-20 04:40:53.115700', '2025-10-20 04:40:53.126860', '2025-10-20', NULL, NULL, NULL, NULL, NULL, '', NULL, 2, NULL, NULL, NULL),
(35, 'YC25100035', 'cấp phát đồng phục mới', 'cấp phát đồng phục mới', 'completed', '2025-10-20 06:14:48.205900', '2025-10-20 06:17:34.909549', '2025-10-20', '2025-10-21 08:00:00', '2025-10-20 06:17:34.909549', '2025-10-20 06:15:34.605426', '', NULL, '', 7, 2, 8, '2025-10-20 06:16:56.244721', NULL),
(36, 'YC25100036', 'Cấp phát đồng phục', 'đồ hư hết rồi cấp đồ mới', 'pending', '2025-10-20 06:25:21.884560', '2025-10-20 06:25:21.908719', '2025-10-20', NULL, NULL, NULL, NULL, NULL, '', NULL, 8, NULL, NULL, NULL),
(37, 'YC25100037', 'test email mới', 'test email mới', 'pending', '2025-10-20 06:34:55.237827', '2025-10-20 06:34:55.249130', '2025-10-20', NULL, NULL, NULL, NULL, NULL, '', NULL, 2, NULL, NULL, NULL),
(38, 'YC25100038', 'cấp phát đồ mới', 'cấp phát đồ mới', 'completed', '2025-10-20 06:37:08.942873', '2025-10-20 06:54:08.180734', '2025-10-20', '2025-10-22 05:56:00', '2025-10-20 06:54:08.180734', '2025-10-20 06:49:39.038177', '', NULL, '', 4, 3, 8, '2025-10-20 06:52:49.225226', NULL),
(39, 'YC25100039', 'Cấp phát đồng phục mới', 'Cấp phát đồng phục mới', 'pending', '2025-10-20 08:03:35.908021', '2025-10-20 08:03:35.970936', '2025-10-20', NULL, NULL, NULL, NULL, NULL, '', NULL, 7, NULL, NULL, NULL),
(40, 'YC25100040', 'Cấp phát đồng phục mới', 'Cấp phát đồng phục mới', 'pending', '2025-10-20 08:04:41.009039', '2025-10-20 08:04:41.059565', '2025-10-20', NULL, NULL, NULL, NULL, NULL, '', NULL, 2, NULL, NULL, NULL),
(41, 'YC25100041', 'thứ cái cấp lịch sử coi sao', 'thứ cái cấp lịch sử coi sao', 'pending', '2025-10-20 08:22:41.901477', '2025-10-20 08:22:41.952797', '2025-10-20', NULL, NULL, NULL, NULL, NULL, '', NULL, 2, NULL, NULL, NULL),
(42, 'YC25100042', 'test thử cấp phát đồ', 'test thử cấp phát đồ', 'completed', '2025-10-20 08:24:15.242496', '2025-10-20 08:28:50.372288', '2025-10-20', '2025-10-21 19:31:00', '2025-10-20 08:28:50.372288', '2025-10-20 08:26:35.241579', '', NULL, '', 4, 3, 8, '2025-10-20 08:27:28.035199', NULL),
(43, 'YC25100043', 'Cấp phát đồ FF', 'Cấp phát đồ FF', 'draft', '2025-10-21 13:12:48.799578', '2025-10-21 13:12:48.799578', '2025-10-21', NULL, NULL, NULL, NULL, NULL, '', NULL, 7, NULL, NULL, NULL),
(44, 'YC25100044', 'cấp phát đồ FF', '', 'pending', '2025-10-21 13:12:59.796334', '2025-10-21 13:12:59.820585', '2025-10-21', NULL, NULL, NULL, NULL, NULL, '', NULL, 7, NULL, NULL, NULL),
(45, 'YC25100045', 'thử cái xem sao', 'thử cái xem sao', 'draft', '2025-10-21 15:56:29.790473', '2025-10-21 15:56:29.790473', '2025-10-21', NULL, NULL, NULL, NULL, NULL, '', NULL, 2, NULL, NULL, NULL),
(46, 'YC25100046', 'rr332r322', '', 'draft', '2025-10-21 15:56:42.486677', '2025-10-21 15:56:42.486677', '2025-10-21', NULL, NULL, NULL, NULL, NULL, '', NULL, 2, NULL, NULL, NULL),
(47, 'YC25100047', '32131232', '', 'rejected', '2025-10-21 15:56:58.657281', '2025-10-21 16:25:22.191189', '2025-10-21', NULL, NULL, '2025-10-21 16:25:22.191189', NULL, 'ko thích', '', 7, 2, NULL, NULL, NULL),
(48, 'YC25100048', 'thửu lần nữ coi sao', '', 'completed', '2025-10-21 16:24:36.834299', '2025-10-21 16:26:27.341621', '2025-10-21', '2025-10-22 08:00:00', '2025-10-21 16:26:27.341621', '2025-10-21 16:25:06.663165', '', NULL, '', 7, 2, 8, '2025-10-21 16:26:09.676036', NULL),
(49, 'YC25100049', 'Cấp phát đồng phục mới', '', 'pending', '2025-10-22 08:17:07.958851', '2025-10-22 08:17:08.008246', '2025-10-22', NULL, NULL, NULL, NULL, NULL, '', NULL, 7, NULL, NULL, NULL);

DROP TABLE IF EXISTS `inventory_requests_requestemployee`;
CREATE TABLE `inventory_requests_requestemployee` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `notes` longtext COLLATE utf8mb4_unicode_ci,
  `employee_id` bigint NOT NULL,
  `request_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_requests_reque_request_id_employee_id_f7664f7e_uniq` (`request_id`,`employee_id`),
  KEY `inventory_requests_r_employee_id_c2ef82cc_fk_employees` (`employee_id`),
  CONSTRAINT `inventory_requests_r_employee_id_c2ef82cc_fk_employees` FOREIGN KEY (`employee_id`) REFERENCES `employees_employee` (`id`),
  CONSTRAINT `inventory_requests_r_request_id_ddedc773_fk_inventory` FOREIGN KEY (`request_id`) REFERENCES `inventory_requests_inventoryrequest` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `inventory_requests_requestitem`;
CREATE TABLE `inventory_requests_requestitem` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `requested_quantity` int unsigned NOT NULL,
  `approved_quantity` int unsigned DEFAULT NULL,
  `issued_quantity` int unsigned NOT NULL,
  `notes` longtext COLLATE utf8mb4_unicode_ci,
  `product_id` bigint NOT NULL,
  `request_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_requests_reque_request_id_product_id_03253f0b_uniq` (`request_id`,`product_id`),
  KEY `inventory_requests_r_product_id_c6b42e67_fk_inventory` (`product_id`),
  CONSTRAINT `inventory_requests_r_product_id_c6b42e67_fk_inventory` FOREIGN KEY (`product_id`) REFERENCES `inventory_product` (`id`),
  CONSTRAINT `inventory_requests_r_request_id_9700aae9_fk_inventory` FOREIGN KEY (`request_id`) REFERENCES `inventory_requests_inventoryrequest` (`id`),
  CONSTRAINT `inventory_requests_requestitem_chk_1` CHECK ((`requested_quantity` >= 0)),
  CONSTRAINT `inventory_requests_requestitem_chk_2` CHECK ((`approved_quantity` >= 0)),
  CONSTRAINT `inventory_requests_requestitem_chk_3` CHECK ((`issued_quantity` >= 0))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `inventory_stockreceipt`;
CREATE TABLE `inventory_stockreceipt` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `receipt_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `receipt_date` date NOT NULL,
  `notes` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `purchase_order_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `receipt_number` (`receipt_number`),
  KEY `inventory_stockrecei_created_by_id_48da1830_fk_accounts_` (`created_by_id`),
  KEY `inventory_stockrecei_purchase_order_id_a998f90e_fk_suppliers` (`purchase_order_id`),
  CONSTRAINT `inventory_stockrecei_created_by_id_48da1830_fk_accounts_` FOREIGN KEY (`created_by_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `inventory_stockrecei_purchase_order_id_a998f90e_fk_suppliers` FOREIGN KEY (`purchase_order_id`) REFERENCES `suppliers_purchaseorder` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_stockreceipt` (`id`, `receipt_number`, `receipt_date`, `notes`, `created_at`, `updated_at`, `created_by_id`, `purchase_order_id`) VALUES
(10, 'NK-20251017-001', '2025-10-17', '', '2025-10-17 03:34:01.187671', '2025-10-17 03:34:01.187671', 1, 3),
(11, 'NK-20251017-002', '2025-10-17', '', '2025-10-17 03:34:18.125684', '2025-10-17 03:34:18.125684', 1, 3),
(12, 'NK-20251017-003', '2025-10-17', '', '2025-10-17 03:58:27.428570', '2025-10-17 03:58:27.428570', 1, 3),
(13, 'NK-20251017-004', '2025-10-17', '', '2025-10-17 04:07:05.085451', '2025-10-17 04:07:05.086443', 1, 3),
(14, 'NK-20251017-005', '2025-10-17', '', '2025-10-17 04:18:07.265919', '2025-10-17 04:18:07.265919', 1, 2),
(15, 'NK-20251017-006', '2025-10-17', '', '2025-10-17 05:58:06.446813', '2025-10-17 05:58:06.446813', 1, 1),
(16, 'NK-20251017-007', '2025-10-17', '', '2025-10-17 07:11:15.070672', '2025-10-17 07:11:15.070672', 1, 4),
(17, 'NK-20251017-008', '2025-10-17', '', '2025-10-17 08:06:55.166814', '2025-10-17 08:06:55.166814', 1, 5);

DROP TABLE IF EXISTS `inventory_stockreceiptitem`;
CREATE TABLE `inventory_stockreceiptitem` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` int unsigned NOT NULL,
  `notes` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `purchase_order_item_id` bigint DEFAULT NULL,
  `receipt_id` bigint NOT NULL,
  `product_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_stockrecei_purchase_order_item__1385ad23_fk_suppliers` (`purchase_order_item_id`),
  KEY `inventory_stockrecei_receipt_id_51b3cb4e_fk_inventory` (`receipt_id`),
  KEY `fk_product` (`product_id`),
  CONSTRAINT `fk_product` FOREIGN KEY (`product_id`) REFERENCES `inventory_product` (`id`),
  CONSTRAINT `inventory_stockrecei_purchase_order_item__1385ad23_fk_suppliers` FOREIGN KEY (`purchase_order_item_id`) REFERENCES `suppliers_purchaseorderitem` (`id`),
  CONSTRAINT `inventory_stockrecei_receipt_id_51b3cb4e_fk_inventory` FOREIGN KEY (`receipt_id`) REFERENCES `inventory_stockreceipt` (`id`),
  CONSTRAINT `inventory_stockreceiptitem_chk_1` CHECK ((`quantity` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_stockreceiptitem` (`id`, `quantity`, `notes`, `created_at`, `purchase_order_item_id`, `receipt_id`, `product_id`) VALUES
(1, 10, NULL, '2025-10-17 10:34:01', 3, 10, 1),
(2, 10, NULL, '2025-10-17 10:34:18', 3, 11, 1),
(3, 30, NULL, '2025-10-17 10:58:27', 3, 12, 1),
(4, 50, NULL, '2025-10-17 11:07:05', 3, 13, 1),
(5, 20, NULL, '2025-10-17 11:18:07', 1, 14, 1),
(6, 10, NULL, '2025-10-17 12:58:06', 4, 15, 2),
(7, 12, NULL, '2025-10-17 14:11:15', 5, 16, 2),
(8, 22, NULL, '2025-10-17 14:11:15', 6, 16, 1),
(9, 9, NULL, '2025-10-17 15:06:55', 7, 17, 3),
(10, 3, NULL, '2025-10-17 15:06:55', 8, 17, 2);

DROP TABLE IF EXISTS `inventory_stocktransaction`;
CREATE TABLE `inventory_stocktransaction` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `transaction_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quantity` int NOT NULL,
  `transaction_date` datetime(6) NOT NULL,
  `notes` longtext COLLATE utf8mb4_unicode_ci,
  `reference_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `transaction_code` (`transaction_code`),
  KEY `inventory_stocktrans_created_by_id_66dde070_fk_accounts_` (`created_by_id`),
  KEY `inventory_stocktrans_product_id_6432f3fb_fk_inventory` (`product_id`),
  CONSTRAINT `inventory_stocktrans_created_by_id_66dde070_fk_accounts_` FOREIGN KEY (`created_by_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `inventory_stocktrans_product_id_6432f3fb_fk_inventory` FOREIGN KEY (`product_id`) REFERENCES `inventory_product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `inventory_unit`;
CREATE TABLE `inventory_unit` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abbreviation` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_unit` (`id`, `name`, `abbreviation`) VALUES
(1, 'Cái', 'Cái'),
(2, 'Bộ', 'Bộ');

DROP TABLE IF EXISTS `inventory_warehouse`;
CREATE TABLE `inventory_warehouse` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `active` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_warehouse` (`id`, `name`, `location`, `description`, `active`, `created_at`, `updated_at`) VALUES
(1, 'KHo GA', NULL, '', 1, '2025-10-16 07:21:53.391911', '2025-10-16 07:21:53.391911');

DROP TABLE IF EXISTS `inventory_warehousecolumn`;
CREATE TABLE `inventory_warehousecolumn` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `column_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `row_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_warehousecolumn_row_id_column_code_f41e11d9_uniq` (`row_id`,`column_code`),
  CONSTRAINT `inventory_warehousec_row_id_f209408d_fk_inventory` FOREIGN KEY (`row_id`) REFERENCES `inventory_warehouserow` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_warehousecolumn` (`id`, `column_code`, `description`, `row_id`) VALUES
(1, 'A001', '', 1),
(2, 'A002', '', 1);

DROP TABLE IF EXISTS `inventory_warehouserow`;
CREATE TABLE `inventory_warehouserow` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `row_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `warehouse_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `inventory_warehouserow_warehouse_id_row_code_8f96f2bb_uniq` (`warehouse_id`,`row_code`),
  CONSTRAINT `inventory_warehouser_warehouse_id_3456675a_fk_inventory` FOREIGN KEY (`warehouse_id`) REFERENCES `inventory_warehouse` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `inventory_warehouserow` (`id`, `row_code`, `description`, `warehouse_id`) VALUES
(1, 'A', '', 1),
(2, 'B', '', 1);

DROP TABLE IF EXISTS `reports_inventory_audit`;
CREATE TABLE `reports_inventory_audit` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `audit_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `audit_date` date NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notes` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `completed_at` datetime(6) DEFAULT NULL,
  `created_by_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `audit_code` (`audit_code`),
  KEY `reports_inventory_au_created_by_id_e8f687c2_fk_accounts_` (`created_by_id`),
  CONSTRAINT `reports_inventory_au_created_by_id_e8f687c2_fk_accounts_` FOREIGN KEY (`created_by_id`) REFERENCES `accounts_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `reports_inventory_audit` (`id`, `audit_code`, `title`, `audit_date`, `status`, `notes`, `created_at`, `updated_at`, `completed_at`, `created_by_id`) VALUES
(1, 'AUD-202510-001', '4543543', '2025-10-21', 'draft', '', '2025-10-21 02:10:38.757829', '2025-10-21 02:10:38.757829', NULL, 1);

DROP TABLE IF EXISTS `reports_inventory_audit_item`;
CREATE TABLE `reports_inventory_audit_item` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `system_quantity` int NOT NULL,
  `actual_quantity` int DEFAULT NULL,
  `notes` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `audit_id` bigint NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reports_inventory_audit_item_audit_id_product_id_ddb69fa0_uniq` (`audit_id`,`product_id`),
  KEY `reports_inventory_au_product_id_a74f8ff4_fk_inventory` (`product_id`),
  CONSTRAINT `reports_inventory_au_audit_id_24f4f193_fk_reports_i` FOREIGN KEY (`audit_id`) REFERENCES `reports_inventory_audit` (`id`),
  CONSTRAINT `reports_inventory_au_product_id_a74f8ff4_fk_inventory` FOREIGN KEY (`product_id`) REFERENCES `inventory_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `reports_inventory_audit_item` (`id`, `system_quantity`, `actual_quantity`, `notes`, `created_at`, `updated_at`, `audit_id`, `product_id`) VALUES
(1, 5, NULL, '', '2025-10-21 02:10:38.769347', '2025-10-21 02:10:38.769347', 1, 3),
(2, 98, NULL, '', '2025-10-21 02:10:38.778045', '2025-10-21 02:10:38.778045', 1, 4),
(3, 95, NULL, '', '2025-10-21 02:10:38.785652', '2025-10-21 02:10:38.785652', 1, 5),
(4, 22, NULL, '', '2025-10-21 02:10:38.790019', '2025-10-21 02:10:38.790019', 1, 2),
(5, 239, NULL, '', '2025-10-21 02:10:38.794627', '2025-10-21 02:10:38.794627', 1, 1);

DROP TABLE IF EXISTS `reports_monthly_inventory_snapshot`;
CREATE TABLE `reports_monthly_inventory_snapshot` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `year` int NOT NULL,
  `month` int NOT NULL,
  `opening_stock` int NOT NULL,
  `closing_stock` int NOT NULL,
  `total_received` int NOT NULL,
  `total_issued` int NOT NULL,
  `is_closed` tinyint(1) NOT NULL,
  `closed_at` datetime(6) DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `product_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reports_monthly_inventor_product_id_year_month_5f5558b5_uniq` (`product_id`,`year`,`month`),
  KEY `reports_mon_year_9e975c_idx` (`year`,`month`),
  KEY `reports_mon_product_6c9459_idx` (`product_id`,`year`,`month`),
  CONSTRAINT `reports_monthly_inve_product_id_77b02e39_fk_inventory` FOREIGN KEY (`product_id`) REFERENCES `inventory_product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `reports_monthly_inventory_snapshot` (`id`, `year`, `month`, `opening_stock`, `closing_stock`, `total_received`, `total_issued`, `is_closed`, `closed_at`, `created_at`, `updated_at`, `product_id`) VALUES
(1, 2025, 10, 5, 5, 0, 0, 1, '2025-10-21 01:45:09.851174', '2025-10-21 01:30:00.968065', '2025-10-21 01:45:09.851174', 3),
(2, 2025, 10, 98, 98, 0, 0, 1, '2025-10-21 01:45:09.833973', '2025-10-21 01:30:00.998253', '2025-10-21 01:45:09.833973', 4),
(3, 2025, 10, 95, 95, 0, 0, 1, '2025-10-21 01:45:09.851174', '2025-10-21 01:30:01.006374', '2025-10-21 01:45:09.851174', 5),
(4, 2025, 10, 22, 22, 0, 0, 1, '2025-10-21 01:45:09.864438', '2025-10-21 01:30:01.015451', '2025-10-21 01:45:09.864438', 2),
(5, 2025, 10, 239, 239, 0, 0, 1, '2025-10-21 01:45:09.864438', '2025-10-21 01:30:01.022557', '2025-10-21 01:45:09.864438', 1);

DROP TABLE IF EXISTS `suppliers_purchaseorder`;
CREATE TABLE `suppliers_purchaseorder` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `po_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_date` date NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `po_image` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `supplier_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_number` (`po_number`),
  KEY `suppliers_purchaseor_supplier_id_398b3921_fk_suppliers` (`supplier_id`),
  CONSTRAINT `suppliers_purchaseor_supplier_id_398b3921_fk_suppliers` FOREIGN KEY (`supplier_id`) REFERENCES `suppliers_supplier` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `suppliers_purchaseorder` (`id`, `po_number`, `order_date`, `status`, `description`, `po_image`, `created_at`, `updated_at`, `supplier_id`) VALUES
(1, '-0-09-09', '2025-10-16', 'approved', '-09-90', '', '2025-10-16 06:49:24.465377', '2025-10-16 06:49:24.465377', 1),
(2, '111112', '2025-10-16', 'approved', '', '', '2025-10-16 08:50:17.245626', '2025-10-16 08:50:17.245626', 2),
(3, '7676756756', '2025-10-17', 'approved', '76756', '', '2025-10-17 02:58:05.257332', '2025-10-17 04:17:52.368698', 2),
(4, '9999999', '2025-10-17', 'approved', '', '', '2025-10-17 06:17:26.296132', '2025-10-17 06:17:44.542435', 2),
(5, 'NHANH0001', '2025-10-17', 'pending', '', '', '2025-10-17 08:05:25.648334', '2025-10-17 08:05:25.648334', 3);

DROP TABLE IF EXISTS `suppliers_purchaseorderitem`;
CREATE TABLE `suppliers_purchaseorderitem` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `quantity` int unsigned NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `product_id` bigint NOT NULL,
  `purchase_order_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `suppliers_purchaseor_product_id_14c4e768_fk_inventory` (`product_id`),
  KEY `suppliers_purchaseor_purchase_order_id_88bbbecb_fk_suppliers` (`purchase_order_id`),
  CONSTRAINT `suppliers_purchaseor_product_id_14c4e768_fk_inventory` FOREIGN KEY (`product_id`) REFERENCES `inventory_product` (`id`),
  CONSTRAINT `suppliers_purchaseor_purchase_order_id_88bbbecb_fk_suppliers` FOREIGN KEY (`purchase_order_id`) REFERENCES `suppliers_purchaseorder` (`id`),
  CONSTRAINT `suppliers_purchaseorderitem_chk_1` CHECK ((`quantity` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `suppliers_purchaseorderitem` (`id`, `quantity`, `unit_price`, `created_at`, `product_id`, `purchase_order_id`) VALUES
(1, 1, '10000.00', '2025-10-17 02:57:40.313624', 1, 2),
(3, 10, '10000.00', '2025-10-17 04:16:08.965544', 1, 3),
(4, 10, '0.00', '2025-10-17 05:58:06.452408', 2, 1),
(5, 12, '0.00', '2025-10-17 07:11:15.078679', 2, 4),
(6, 22, '10000.00', '2025-10-17 07:11:15.085785', 1, 4),
(7, 9, '0.00', '2025-10-17 08:06:55.170812', 3, 5),
(8, 3, '0.00', '2025-10-17 08:06:55.179482', 2, 5);

DROP TABLE IF EXISTS `suppliers_supplier`;
CREATE TABLE `suppliers_supplier` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` longtext COLLATE utf8mb4_unicode_ci,
  `contact_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_email` varchar(254) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `suppliers_supplier` (`id`, `code`, `name`, `address`, `contact_name`, `contact_phone`, `contact_email`, `created_at`, `updated_at`) VALUES
(1, '9987989', '9879798798', '', '-0-0-09-9', '978987978', NULL, '2025-10-16 06:49:11.541292', '2025-10-16 06:49:11.541292'),
(2, 'A111111', 'Công ty ABC', '', 'Công ty ABC', '123456789', NULL, '2025-10-16 08:50:07.146200', '2025-10-16 08:50:07.146200'),
(3, 'NHANHNHANH', 'Công ty Nhanh Nhanh', '', 'Việt', '0965441303', NULL, '2025-10-17 08:05:09.843265', '2025-10-17 08:05:09.843265');

DROP TABLE IF EXISTS `system_settings_emailconfiguration`;
CREATE TABLE `system_settings_emailconfiguration` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `smtp_host` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `smtp_port` int unsigned NOT NULL,
  `smtp_username` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtp_password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `from_email` varchar(254) COLLATE utf8mb4_unicode_ci NOT NULL,
  `use_tls` tinyint(1) NOT NULL,
  `use_ssl` tinyint(1) NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `last_test_success` tinyint(1) DEFAULT NULL,
  `last_test_date` datetime(6) DEFAULT NULL,
  `created_by_id` bigint DEFAULT NULL,
  `updated_by_id` bigint DEFAULT NULL,
  `auth_method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `smtp_conn_timeout` int unsigned NOT NULL,
  `smtp_timeout` int unsigned NOT NULL,
  `from_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `system_settings_emai_created_by_id_31e741aa_fk_accounts_` (`created_by_id`),
  KEY `system_settings_emai_updated_by_id_c9253a31_fk_accounts_` (`updated_by_id`),
  CONSTRAINT `system_settings_emai_created_by_id_31e741aa_fk_accounts_` FOREIGN KEY (`created_by_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `system_settings_emai_updated_by_id_c9253a31_fk_accounts_` FOREIGN KEY (`updated_by_id`) REFERENCES `accounts_user` (`id`),
  CONSTRAINT `system_settings_emailconfiguration_chk_1` CHECK ((`smtp_port` >= 0)),
  CONSTRAINT `system_settings_emailconfiguration_chk_2` CHECK ((`smtp_conn_timeout` >= 0)),
  CONSTRAINT `system_settings_emailconfiguration_chk_3` CHECK ((`smtp_timeout` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `system_settings_emailconfiguration` (`id`, `smtp_host`, `smtp_port`, `smtp_username`, `smtp_password`, `from_email`, `use_tls`, `use_ssl`, `created_at`, `updated_at`, `is_active`, `last_test_success`, `last_test_date`, `created_by_id`, `updated_by_id`, `auth_method`, `smtp_conn_timeout`, `smtp_timeout`, `from_name`) VALUES
(1, '10.156.1.150', 25, '321321', '', 'GA_warehouse@olympus.com', 0, 0, '2025-10-18 01:40:37.862707', '2025-10-20 06:34:15.190474', 1, NULL, NULL, 1, 1, 'none', 60000, 60000, 'GA warehouse');

DROP TABLE IF EXISTS `system_settings_emailtemplate`;
CREATE TABLE `system_settings_emailtemplate` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci,
  `is_html` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `variables` json NOT NULL,
  `created_at` datetime(6) NOT NULL,
  `updated_at` datetime(6) NOT NULL,
  `default_cc` longtext COLLATE utf8mb4_unicode_ci,
  `default_recipients` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `system_settings_emailtemplate` (`id`, `code`, `type`, `name`, `subject`, `content`, `description`, `is_html`, `is_active`, `variables`, `created_at`, `updated_at`, `default_cc`, `default_recipients`) VALUES
(1, 'request_created', 'notification', 'Thông báo tạo yêu cầu mới', 'Yêu cầu cấp phát #{{ request.request_code }} đã được tạo thành công', '<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yêu cầu cấp phát mới</title>
    <style>
        body {
            font-family: ''Segoe UI'', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 900px;
            margin: 20px auto;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        .content {
            padding: 30px;
        }
        .greeting {
            font-size: 16px;
            margin-bottom: 20px;
            color: #555;
        }
        .info-box {
            background: #f8f9fa;
            border-left: 4px solid #667eea;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
        }
        .info-box h3 {
            margin-top: 0;
            color: #667eea;
            font-size: 18px;
        }
        .info-row {
            display: flex;
            padding: 10px 0;
            border-bottom: 1px solid #e0e0e0;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .info-label {
            font-weight: 600;
            width: 180px;
            color: #555;
        }
        .info-value {
            flex: 1;
            color: #333;
        }
        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            background: #ffc107;
            color: #000;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
        }
        .table-container {
            margin: 30px 0;
            overflow-x: auto;
        }
        .table-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            background: white;
        }
        thead {
            background: #667eea;
            color: white;
        }
        th {
            padding: 12px 8px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
        }
        td {
            padding: 12px 8px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 13px;
        }
        tbody tr:hover {
            background-color: #f8f9fa;
        }
        tbody tr:last-child td {
            border-bottom: none;
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
        .history-badge {
            display: inline-block;
            padding: 3px 8px;
            background: #28a745;
            color: white;
            border-radius: 3px;
            font-size: 11px;
            margin-top: 3px;
        }
        .no-history {
            color: #999;
            font-size: 11px;
        }
        .note {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 15px;
            margin: 20px 0;
            border-radius: 5px;
        }
        .footer {
            background: #f8f9fa;
            padding: 20px 30px;
            text-align: center;
            color: #777;
            font-size: 14px;
            border-top: 1px solid #e0e0e0;
        }
        .footer p {
            margin: 5px 0;
        }
        .button {
            display: inline-block;
            padding: 12px 30px;
            background: #667eea;
            color: white !important;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            margin: 20px 0;
            transition: background 0.3s;
        }
        .button:hover {
            background: #5568d3;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Yêu cầu cấp phát đã được tạo thành công</h1>
        </div>
        
        <div class="content">
            <div class="greeting">
                Kính gửi <strong>{{ user.get_full_name }}</strong>,
            </div>
            
            <p>Yêu cầu cấp phát của bạn đã được tạo thành công và đã được gửi đến người phê duyệt để xem xét.</p>
            
            <div class="info-box">
                <h3>Thông tin yêu cầu</h3>
                <div class="info-row">
                    <div class="info-label">Mã yêu cầu:</div>
                    <div class="info-value"><strong>{{ request.request_code }}</strong></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Tiêu đề:</div>
                    <div class="info-value">{{ request.title }}</div>
                </div>
                <div class="info-row">
                    <div class="info-label">Trạng thái:</div>
                    <div class="info-value"><span class="status-badge">Chờ phê duyệt</span></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Ngày tạo:</div>
                    <div class="info-value">{{ request.created_at|date:"d/m/Y H:i" }}</div>
                </div>
                <div class="info-row">
                    <div class="info-label">Ngày mong muốn nhận:</div>
                    <div class="info-value">{{ request.expected_date|date:"d/m/Y" }}</div>
                </div>
                {% if request.notes %}
                <div class="info-row">
                    <div class="info-label">Ghi chú:</div>
                    <div class="info-value">{{ request.notes }}</div>
                </div>
                {% endif %}
            </div>
            
            <div class="table-container">
                <div class="table-title">Chi tiết phân bổ sản phẩm cho nhân viên</div>
                <table>
                    <thead>
                        <tr>
                            <th style="width: 4%;">#</th>
                            <th style="width: 22%;">Nhân viên</th>
                            <th style="width: 25%;">Sản phẩm</th>
                            <th style="width: 10%;" class="text-center">SL</th>
                            <th style="width: 22%;">Lần lấy gần nhất</th>
                            <th style="width: 17%;">Ghi chú</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for item in employee_products_with_history %}
                        <tr>
                            <td class="text-center">{{ forloop.counter }}</td>
                            <td>
                                <strong>{{ item.employee_product.employee.full_name }}</strong><br>
                                <small style="color: #777;">{{ item.employee_product.employee.employee_id }}</small>
                            </td>
                            <td>
                                <strong>{{ item.employee_product.product.name }}</strong><br>
                                <small style="color: #777;">Mã: {{ item.employee_product.product.product_code }}</small>
                            </td>
                            <td class="text-center"><strong>{{ item.employee_product.quantity }}</strong></td>
                            <td>
                                {% if item.last_delivery %}
                                <small>
                                    📅 {{ item.last_delivery.request.completed_date|date:"d/m/Y" }}<br>
                                    📦 SL: {{ item.last_delivery.quantity }}<br>
                                    <span class="history-badge">{{ item.last_delivery.request.request_code }}</span>
                                </small>
                                {% else %}
                                <small class="no-history">Chưa từng lấy</small>
                                {% endif %}
                            </td>
                            <td><small>{{ item.employee_product.notes|default:"—" }}</small></td>
                        </tr>
                        {% empty %}
                        <tr>
                            <td colspan="6" class="text-center" style="color: #999;">Chưa có phân bổ nào</td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
            
            <div class="note">
                <strong>Lưu ý:</strong> Bạn có thể theo dõi trạng thái yêu cầu của mình trong phần <strong>"Yêu cầu của tôi"</strong> trên hệ thống. Bạn sẽ nhận được thông báo qua email khi yêu cầu được phê duyệt hoặc từ chối.
            </div>
            
            <div style="text-align: center;">
                <a href="#" class="button">Xem chi tiết yêu cầu</a>
            </div>
        </div>
        
        <div class="footer">
            <p><strong>Hệ thống Quản lý Kho</strong></p>
            <p>Email này được gửi tự động, vui lòng không trả lời.</p>
            <p style="color: #999; font-size: 12px;">(c) 2025 OVNC Inventory Management System</p>
        </div>
    </div>
</body>
</html>', 'Email gửi cho người tạo yêu cầu khi yêu cầu được tạo thành công', 1, 1, '{"status": "", "created_at": "", "request_id": "", "request_url": "", "recipient_name": "", "requested_date": "", "requester_name": "", "requester_email": ""}', '2025-10-18 02:29:03.369926', '2025-10-20 08:18:31.495087', NULL, NULL),
(2, 'pending_approval', 'notification', 'Thông báo yêu cầu chờ phê duyệt', '[Cần phê duyệt] Yêu cầu cấp phát #{{ request.request_code }}', '<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yêu cầu chờ phê duyệt</title>
    <style>
        body {
            font-family: ''Segoe UI'', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 900px;
            margin: 20px auto;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            overflow: hidden;
        }
        .header {
            background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
        }
        .urgent-badge {
            display: inline-block;
            background: #fff;
            color: #f5576c;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 700;
            margin-top: 10px;
        }
        .content {
            padding: 30px;
        }
        .greeting {
            font-size: 16px;
            margin-bottom: 20px;
            color: #555;
        }
        .alert-box {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
        }
        .alert-box strong {
            color: #856404;
        }
        .info-box {
            background: #f8f9fa;
            border-left: 4px solid #f5576c;
            padding: 20px;
            margin: 20px 0;
            border-radius: 5px;
        }
        .info-box h3 {
            margin-top: 0;
            color: #f5576c;
            font-size: 18px;
        }
        .info-row {
            display: flex;
            padding: 10px 0;
            border-bottom: 1px solid #e0e0e0;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .info-label {
            font-weight: 600;
            width: 180px;
            color: #555;
        }
        .info-value {
            flex: 1;
            color: #333;
        }
        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            background: #ffc107;
            color: #000;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 600;
        }
        .table-container {
            margin: 30px 0;
            overflow-x: auto;
        }
        .table-title {
            font-size: 18px;
            font-weight: 600;
            color: #333;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f5576c;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
            background: white;
        }
        thead {
            background: #f5576c;
            color: white;
        }
        th {
            padding: 12px 8px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
        }
        td {
            padding: 12px 8px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 13px;
        }
        tbody tr:hover {
            background-color: #fff5f5;
        }
        tbody tr:last-child td {
            border-bottom: none;
        }
        .text-right {
            text-align: right;
        }
        .text-center {
            text-align: center;
        }
        .history-badge {
            display: inline-block;
            padding: 3px 8px;
            background: #28a745;
            color: white;
            border-radius: 3px;
            font-size: 11px;
            margin-top: 3px;
        }
        .no-history {
            color: #999;
            font-size: 11px;
        }
        .action-buttons {
            text-align: center;
            margin: 30px 0;
        }
        .button {
            display: inline-block;
            padding: 14px 35px;
            margin: 0 10px;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            transition: all 0.3s;
            font-size: 16px;
        }
        .button-approve {
            background: #28a745;
            color: white !important;
        }
        .button-approve:hover {
            background: #218838;
        }
        .button-view {
            background: #007bff;
            color: white !important;
        }
        .button-view:hover {
            background: #0056b3;
        }
        .footer {
            background: #f8f9fa;
            padding: 20px 30px;
            text-align: center;
            color: #777;
            font-size: 14px;
            border-top: 1px solid #e0e0e0;
        }
        .footer p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Yêu cầu cấp phát cần phê duyệt</h1>
            <span class="urgent-badge">CẦN XỬ LÝ</span>
        </div>
        
        <div class="content">
            <div class="greeting">
                Kính gửi <strong>{{ manager.get_full_name }}</strong>,
            </div>
            
            <div class="alert-box">
                <strong>Bạn có một yêu cầu cấp phát mới cần phê duyệt!</strong><br>
                Yêu cầu từ <strong>{{ user.get_full_name }}</strong> ({{ user.email }}) đang chờ bạn xem xét và phê duyệt.
            </div>
            
            <div class="info-box">
                <h3>Thông tin yêu cầu</h3>
                <div class="info-row">
                    <div class="info-label">Mã yêu cầu:</div>
                    <div class="info-value"><strong>{{ request.request_code }}</strong></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Tiêu đề:</div>
                    <div class="info-value">{{ request.title }}</div>
                </div>
                <div class="info-row">
                    <div class="info-label">Trạng thái:</div>
                    <div class="info-value"><span class="status-badge">Chờ phê duyệt</span></div>
                </div>
                <div class="info-row">
                    <div class="info-label">Người yêu cầu:</div>
                    <div class="info-value">{{ user.get_full_name }} ({{ user.email }})</div>
                </div>
                <div class="info-row">
                    <div class="info-label">Ngày tạo:</div>
                    <div class="info-value">{{ request.created_at|date:"d/m/Y H:i" }}</div>
                </div>
                <div class="info-row">
                    <div class="info-label">Ngày mong muốn nhận:</div>
                    <div class="info-value"><strong>{{ request.expected_date|date:"d/m/Y" }}</strong></div>
                </div>
                {% if request.notes %}
                <div class="info-row">
                    <div class="info-label">Ghi chú:</div>
                    <div class="info-value">{{ request.notes }}</div>
                </div>
                {% endif %}
            </div>
            
            <div class="table-container">
                <div class="table-title">Chi tiết phân bổ sản phẩm cho nhân viên (có lịch sử lấy hàng)</div>
                <table>
                    <thead>
                        <tr>
                            <th style="width: 4%;">#</th>
                            <th style="width: 22%;">Nhân viên</th>
                            <th style="width: 25%;">Sản phẩm</th>
                            <th style="width: 10%;" class="text-center">SL</th>
                            <th style="width: 22%;">Lần lấy gần nhất</th>
                            <th style="width: 17%;">Ghi chú</th>
                        </tr>
                    </thead>
                    <tbody>
                        {% for item in employee_products_with_history %}
                        <tr>
                            <td class="text-center">{{ forloop.counter }}</td>
                            <td>
                                <strong>{{ item.employee_product.employee.full_name }}</strong><br>
                                <small style="color: #777;">{{ item.employee_product.employee.employee_id }}</small>
                            </td>
                            <td>
                                <strong>{{ item.employee_product.product.name }}</strong><br>
                                <small style="color: #777;">Mã: {{ item.employee_product.product.product_code }}</small>
                            </td>
                            <td class="text-center"><strong>{{ item.employee_product.quantity }}</strong></td>
                            <td>
                                {% if item.last_delivery %}
                                <small>
                                    📅 {{ item.last_delivery.request.completed_date|date:"d/m/Y" }}<br>
                                    📦 SL: {{ item.last_delivery.quantity }}<br>
                                    <span class="history-badge">{{ item.last_delivery.request.request_code }}</span>
                                </small>
                                {% else %}
                                <small class="no-history">Chưa từng lấy</small>
                                {% endif %}
                            </td>
                            <td><small>{{ item.employee_product.notes|default:"—" }}</small></td>
                        </tr>
                        {% empty %}
                        <tr>
                            <td colspan="6" class="text-center" style="color: #999;">Chưa có phân bổ nào</td>
                        </tr>
                        {% endfor %}
                    </tbody>
                </table>
            </div>
            
            <div class="action-buttons">
                <a href="#" class="button button-approve">PHÊ DUYỆT YÊU CẦU</a>
                <a href="#" class="button button-view">XEM CHI TIẾT</a>
            </div>
            
            <p style="text-align: center; color: #777; font-size: 14px; margin-top: 20px;">
                Hoặc đăng nhập vào hệ thống và truy cập phần <strong>"Phê duyệt của tôi"</strong> để xử lý yêu cầu này.
            </p>
        </div>
        
        <div class="footer">
            <p><strong>Hệ thống Quản lý Kho</strong></p>
            <p>Email này được gửi tự động, vui lòng không trả lời.</p>
            <p style="color: #999; font-size: 12px;">(c) 2025 OVNC Inventory Management System</p>
        </div>
    </div>
</body>
</html>', 'Email gửi cho quản lý khi có yêu cầu cần phê duyệt', 1, 1, '{"created_at": "", "reject_url": "", "request_id": "", "approve_url": "", "request_url": "", "approver_name": "", "requested_date": "", "requester_name": "", "requester_email": ""}', '2025-10-18 02:29:03.376029', '2025-10-20 08:18:31.508190', NULL, NULL),
(3, 'request_approved', 'request_approved', 'Thông báo yêu cầu được phê duyệt', 'Yêu cầu #{{ request.request_code }} đã được phê duyệt', '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        
        body {
            font-family: ''Segoe UI'', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 700px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
        }
        .email-container {
            background: #ffffff;
            border: 2px solid #ddd;
            border-radius: 8px;
            padding: 0;
        }
        .header {
            padding: 30px;
            text-align: center;
            border-radius: 6px 6px 0 0;
            border-bottom: 3px solid #ddd;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
            color: #333;
        }
        .header p {
            margin: 10px 0 0 0;
            font-size: 14px;
            color: #666;
        }
        .content-box {
            background: #ffffff;
            padding: 30px;
        }
        .message-box {
            background: #f8f9fa;
            border-left: 4px solid #28a745;
            padding: 20px;
            margin-bottom: 25px;
        }
        .message-box.rejected {
            border-left-color: #dc3545;
        }
        .message-box h2 {
            margin: 0 0 10px 0;
            font-size: 18px;
            color: #333;
        }
        .message-box p {
            margin: 0;
            font-size: 14px;
            color: #555;
        }
        .info-box {
            background: #ffffff;
            border: 1px solid #e0e0e0;
            padding: 20px;
            margin: 20px 0;
            border-radius: 6px;
        }
        .info-box h3 {
            margin-top: 0;
            color: #28a745;
            font-size: 16px;
            border-bottom: 2px solid #28a745;
            padding-bottom: 10px;
        }
        .info-box.rejected h3 {
            color: #dc3545;
            border-bottom-color: #dc3545;
        }
        .info-row {
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .label {
            font-weight: 600;
            color: #555;
            display: inline-block;
            min-width: 150px;
        }
        .value {
            color: #333;
        }
        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-approved {
            background: #d4edda;
            color: #155724;
            border: 1px solid #28a745;
        }
        .status-rejected {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #dc3545;
        }
        .product-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            border: 1px solid #e0e0e0;
        }
        .product-table thead {
            background: #28a745;
        }
        .product-table thead.rejected {
            background: #dc3545;
        }
        .product-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
            color: #ffffff;
            border: 1px solid #1e7e34;
        }
        .product-table.rejected th {
            border-color: #bd2130;
        }
        .product-table td {
            padding: 12px;
            border: 1px solid #e0e0e0;
            color: #333;
        }
        .product-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .product-code {
            display: inline-block;
            background: #28a745;
            color: #ffffff;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 600;
        }
        .product-code.rejected {
            background: #dc3545;
        }
        .button {
            display: inline-block;
            padding: 12px 30px;
            background: #007bff;
            color: #ffffff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            margin: 10px 5px;
        }
        .footer {
            text-align: center;
            color: #666;
            margin-top: 30px;
            padding: 20px;
            border-top: 2px solid #e0e0e0;
            font-size: 12px;
        }
        .footer p {
            margin: 5px 0;
        }
        
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header" style="border-bottom-color: #28a745;">
            <h1>YÊU CẦU ĐÃ ĐƯỢC PHÊ DUYỆT</h1>
            <p>Mã yêu cầu: #{{ request.request_code }}</p>
        </div>

        <div class="content-box">
            <div class="message-box">
                <h2>Xin chào {{ request.requester.get_full_name }},</h2>
                <p>Yêu cầu cấp phát vật tư của bạn đã được phê duyệt bởi {{ request.approver.get_full_name }}.</p>
            </div>

            <div class="info-box">
                <h3>THÔNG TIN YÊU CẦU</h3>
                <div class="info-row">
                    <span class="label">Mã yêu cầu:</span>
                    <span class="value"><strong>#{{ request.request_code }}</strong></span>
                </div>
                <div class="info-row">
                    <span class="label">Tiêu đề:</span>
                    <span class="value">{{ request.title }}</span>
                </div>
                <div class="info-row">
                    <span class="label">Người phê duyệt:</span>
                    <span class="value">{{ request.approver.get_full_name }} ({{ request.approver.email }})</span>
                </div>
                <div class="info-row">
                    <span class="label">Ngày phê duyệt:</span>
                    <span class="value">{{ request.approval_date|date:"d/m/Y H:i" }}</span>
                </div>
                <div class="info-row">
                    <span class="label">Trạng thái:</span>
                    <span class="value"><span class="status-badge status-approved">Đã phê duyệt</span></span>
                </div>
            </div>

            <h3 style="color: #28a745; margin-top: 30px; border-bottom: 2px solid #28a745; padding-bottom: 10px;">DANH SÁCH VẬT TƯ ĐÃ DUYỆT</h3>
            <table class="product-table">
                <thead>
                    <tr>
                        <th>Nhân viên</th>
                        <th>Sản phẩm</th>
                        <th style="text-align: center;">Số lượng</th>
                    </tr>
                </thead>
                <tbody>
                    {% for employee_product in request.employee_products.all %}
                    <tr>
                        <td>
                            <strong>{{ employee_product.employee.full_name }}</strong><br>
                            <small style="color: #666;">{{ employee_product.employee.department.name|default:"N/A" }}</small>
                        </td>
                        <td>
                            <span class="product-code">{{ employee_product.product.product_code }}</span><br>
                            {{ employee_product.product.name }}
                        </td>
                        <td style="text-align: center;"><strong style="color: #28a745; font-size: 16px;">{{ employee_product.quantity }}</strong></td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>

            {% if request.approval_note %}
            <div style="background: #d4edda; border: 1px solid #28a745; border-left: 4px solid #28a745; padding: 15px; margin: 20px 0; border-radius: 4px;">
                <strong style="color: #155724;">Ghi chú từ người phê duyệt:</strong>
                <p style="margin: 5px 0; color: #333;">{{ request.approval_note }}</p>
            </div>
            {% endif %}

            <div style="background: #e7f5ed; border: 1px solid #28a745; border-left: 4px solid #28a745; padding: 20px; margin: 20px 0; border-radius: 4px;">
                <h3 style="margin-top: 0; color: #155724; font-size: 16px;">CÁC BƯỚC TIẾP THEO</h3>
                <ul style="margin: 10px 0; padding-left: 25px;">
                    <li style="margin: 8px 0; color: #333;">Yêu cầu đang chờ bộ phận kho lên lịch cấp phát</li>
                    <li style="margin: 8px 0; color: #333;">Bạn sẽ nhận được thông báo khi lịch cấp phát được xác nhận</li>
                    <li style="margin: 8px 0; color: #333;">Vui lòng sắp xếp thời gian nhận hàng theo lịch đã được thông báo</li>
                </ul>
            </div>

            <div style="text-align: center; margin: 30px 0;">
                <a href="http://127.0.0.1:8000/inventory/requests/{{ request.id }}/" class="button" style="background: #28a745;">Xem chi tiết yêu cầu</a>
            </div>
        </div>

        <div class="footer">
            <p><strong>OVNC Inventory Management System</strong></p>
            <p>Email này được gửi tự động, vui lòng không trả lời.</p>
            <p>&copy; 2025 OVNC. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
                ', 'Email gửi cho người tạo yêu cầu khi yêu cầu được phê duyệt', 1, 1, '{"request_id": "", "approved_at": "", "request_url": "", "approval_note": "", "approver_name": "", "requested_date": "", "requester_name": ""}', '2025-10-18 02:29:03.382583', '2025-10-20 03:12:30.309185', NULL, NULL),
(4, 'request_rejected', 'request_rejected', 'Thông báo yêu cầu bị từ chối', 'Yêu cầu #{{ request.request_code }} đã bị từ chối', '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        
        body {
            font-family: ''Segoe UI'', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 700px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
        }
        .email-container {
            background: #ffffff;
            border: 2px solid #ddd;
            border-radius: 8px;
            padding: 0;
        }
        .header {
            padding: 30px;
            text-align: center;
            border-radius: 6px 6px 0 0;
            border-bottom: 3px solid #ddd;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
            color: #333;
        }
        .header p {
            margin: 10px 0 0 0;
            font-size: 14px;
            color: #666;
        }
        .content-box {
            background: #ffffff;
            padding: 30px;
        }
        .message-box {
            background: #f8f9fa;
            border-left: 4px solid #28a745;
            padding: 20px;
            margin-bottom: 25px;
        }
        .message-box.rejected {
            border-left-color: #dc3545;
        }
        .message-box h2 {
            margin: 0 0 10px 0;
            font-size: 18px;
            color: #333;
        }
        .message-box p {
            margin: 0;
            font-size: 14px;
            color: #555;
        }
        .info-box {
            background: #ffffff;
            border: 1px solid #e0e0e0;
            padding: 20px;
            margin: 20px 0;
            border-radius: 6px;
        }
        .info-box h3 {
            margin-top: 0;
            color: #28a745;
            font-size: 16px;
            border-bottom: 2px solid #28a745;
            padding-bottom: 10px;
        }
        .info-box.rejected h3 {
            color: #dc3545;
            border-bottom-color: #dc3545;
        }
        .info-row {
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .label {
            font-weight: 600;
            color: #555;
            display: inline-block;
            min-width: 150px;
        }
        .value {
            color: #333;
        }
        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-approved {
            background: #d4edda;
            color: #155724;
            border: 1px solid #28a745;
        }
        .status-rejected {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #dc3545;
        }
        .product-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            border: 1px solid #e0e0e0;
        }
        .product-table thead {
            background: #28a745;
        }
        .product-table thead.rejected {
            background: #dc3545;
        }
        .product-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
            color: #ffffff;
            border: 1px solid #1e7e34;
        }
        .product-table.rejected th {
            border-color: #bd2130;
        }
        .product-table td {
            padding: 12px;
            border: 1px solid #e0e0e0;
            color: #333;
        }
        .product-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .product-code {
            display: inline-block;
            background: #28a745;
            color: #ffffff;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 600;
        }
        .product-code.rejected {
            background: #dc3545;
        }
        .button {
            display: inline-block;
            padding: 12px 30px;
            background: #007bff;
            color: #ffffff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            margin: 10px 5px;
        }
        .footer {
            text-align: center;
            color: #666;
            margin-top: 30px;
            padding: 20px;
            border-top: 2px solid #e0e0e0;
            font-size: 12px;
        }
        .footer p {
            margin: 5px 0;
        }
        
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header" style="border-bottom-color: #dc3545;">
            <h1>YÊU CẦU BỊ TỪ CHỐI</h1>
            <p>Mã yêu cầu: #{{ request.request_code }}</p>
        </div>

        <div class="content-box">
            <div class="message-box rejected">
                <h2>Xin chào {{ request.requester.get_full_name }},</h2>
                <p>Rất tiếc, yêu cầu cấp phát vật tư của bạn đã bị từ chối bởi {{ request.approver.get_full_name }}.</p>
            </div>

            <div class="info-box rejected">
                <h3>THÔNG TIN YÊU CẦU</h3>
                <div class="info-row">
                    <span class="label">Mã yêu cầu:</span>
                    <span class="value"><strong>#{{ request.request_code }}</strong></span>
                </div>
                <div class="info-row">
                    <span class="label">Tiêu đề:</span>
                    <span class="value">{{ request.title }}</span>
                </div>
                <div class="info-row">
                    <span class="label">Người từ chối:</span>
                    <span class="value">{{ request.approver.get_full_name }} ({{ request.approver.email }})</span>
                </div>
                <div class="info-row">
                    <span class="label">Ngày từ chối:</span>
                    <span class="value">{{ request.approval_date|date:"d/m/Y H:i" }}</span>
                </div>
                <div class="info-row">
                    <span class="label">Trạng thái:</span>
                    <span class="value"><span class="status-badge status-rejected">Đã từ chối</span></span>
                </div>
            </div>

            {% if request.approval_note %}
            <div style="background: #f8d7da; border: 1px solid #dc3545; border-left: 4px solid #dc3545; padding: 20px; margin: 20px 0; border-radius: 4px;">
                <strong style="color: #721c24; font-size: 16px;">Lý do từ chối:</strong>
                <p style="margin: 10px 0; color: #333; font-size: 14px; line-height: 1.6;">{{ request.approval_note }}</p>
            </div>
            {% endif %}

            <h3 style="color: #dc3545; margin-top: 30px; border-bottom: 2px solid #dc3545; padding-bottom: 10px;">DANH SÁCH VẬT TƯ</h3>
            <table class="product-table rejected">
                <thead class="rejected">
                    <tr>
                        <th>Nhân viên</th>
                        <th>Sản phẩm</th>
                        <th style="text-align: center;">Số lượng</th>
                    </tr>
                </thead>
                <tbody>
                    {% for employee_product in request.employee_products.all %}
                    <tr>
                        <td>
                            <strong>{{ employee_product.employee.full_name }}</strong><br>
                            <small style="color: #666;">{{ employee_product.employee.department.name|default:"N/A" }}</small>
                        </td>
                        <td>
                            <span class="product-code rejected">{{ employee_product.product.product_code }}</span><br>
                            {{ employee_product.product.name }}
                        </td>
                        <td style="text-align: center;"><strong style="color: #dc3545; font-size: 16px;">{{ employee_product.quantity }}</strong></td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>

            <div style="background: #fff3e0; border: 1px solid #ff9800; border-left: 4px solid #ff9800; padding: 20px; margin: 20px 0; border-radius: 4px;">
                <h3 style="margin-top: 0; color: #e65100; font-size: 16px;">BẠN CÓ THỂ</h3>
                <ul style="margin: 10px 0; padding-left: 25px;">
                    <li style="margin: 8px 0; color: #333;">Liên hệ với người quản lý để hiểu rõ hơn về lý do từ chối</li>
                    <li style="margin: 8px 0; color: #333;">Điều chỉnh yêu cầu theo phản hồi và tạo yêu cầu mới</li>
                    <li style="margin: 8px 0; color: #333;">Kiểm tra lại quy trình và điều kiện cấp phát vật tư</li>
                </ul>
            </div>

            <div style="text-align: center; margin: 30px 0;">
                <a href="http://127.0.0.1:8000/inventory/requests/{{ request.id }}/" class="button">Xem chi tiết yêu cầu</a>
                <a href="http://127.0.0.1:8000/inventory/requests/create/" class="button" style="background: #28a745;">Tạo yêu cầu mới</a>
            </div>
        </div>

        <div class="footer">
            <p><strong>OVNC Inventory Management System</strong></p>
            <p>Email này được gửi tự động, vui lòng không trả lời.</p>
            <p>Nếu có thắc mắc, vui lòng liên hệ: support@ovnc.com</p>
            <p>&copy; 2025 OVNC. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
                ', 'Email gửi cho người tạo yêu cầu khi yêu cầu bị từ chối', 1, 1, '{"request_id": "", "rejected_at": "", "request_url": "", "approver_name": "", "requester_name": "", "rejection_reason": ""}', '2025-10-18 02:29:03.382583', '2025-10-20 03:12:30.309185', NULL, NULL),
(5, 'warehouse_scheduled', 'notification', 'Thông báo đã lên lịch cấp phát', 'Đã lên lịch cấp phát #{{ request.request_code }}', '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: ''Segoe UI'', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 700px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
        }
        .email-container {
            background: #ffffff;
            border: 2px solid #ddd;
            border-radius: 8px;
            padding: 0;
        }
        .header {
            padding: 30px;
            text-align: center;
            border-radius: 6px 6px 0 0;
            border-bottom: 3px solid #ff9800;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
            color: #333;
        }
        .header p {
            margin: 10px 0 0 0;
            font-size: 14px;
            color: #666;
        }
        .content-box {
            background: #ffffff;
            padding: 30px;
        }
        .message-box {
            background: #f8f9fa;
            border-left: 4px solid #ff9800;
            padding: 20px;
            margin-bottom: 25px;
        }
        .message-box h2 {
            margin: 0 0 10px 0;
            font-size: 18px;
            color: #333;
        }
        .message-box p {
            margin: 0;
            font-size: 14px;
            color: #555;
        }
        .info-box {
            background: #ffffff;
            border: 1px solid #e0e0e0;
            padding: 20px;
            margin: 20px 0;
            border-radius: 6px;
        }
        .info-box h3 {
            margin-top: 0;
            color: #ff9800;
            font-size: 16px;
            border-bottom: 2px solid #ff9800;
            padding-bottom: 10px;
        }
        .info-row {
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .label {
            font-weight: 600;
            color: #555;
            display: inline-block;
            min-width: 150px;
        }
        .value {
            color: #333;
        }
        .schedule-highlight {
            background: #fff3e0;
            border: 2px solid #ff9800;
            border-left: 4px solid #ff9800;
            padding: 25px;
            margin: 25px 0;
            border-radius: 6px;
        }
        .schedule-highlight h3 {
            margin-top: 0;
            color: #e65100;
            font-size: 18px;
        }
        .schedule-datetime {
            background: #ffffff;
            border: 2px solid #ff9800;
            padding: 15px;
            border-radius: 5px;
            text-align: center;
            margin: 15px 0;
        }
        .schedule-datetime .date {
            font-size: 24px;
            font-weight: 700;
            color: #ff9800;
            margin: 0;
        }
        .schedule-datetime .time {
            font-size: 18px;
            color: #666;
            margin: 5px 0 0 0;
        }
        .product-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            border: 1px solid #e0e0e0;
        }
        .product-table thead {
            background: #ff9800;
        }
        .product-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
            color: #ffffff;
            border: 1px solid #f57c00;
        }
        .product-table td {
            padding: 12px;
            border: 1px solid #e0e0e0;
            color: #333;
        }
        .product-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .product-code {
            display: inline-block;
            background: #ff9800;
            color: #ffffff;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 600;
        }
        .button {
            display: inline-block;
            padding: 12px 30px;
            background: #007bff;
            color: #ffffff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            margin: 10px 5px;
        }
        .footer {
            text-align: center;
            color: #666;
            margin-top: 30px;
            padding: 20px;
            border-top: 2px solid #e0e0e0;
            font-size: 12px;
        }
        .footer p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <h1>ĐÃ LÊN LỊCH CẤP PHÁT</h1>
            <p>Mã yêu cầu: #{{ request.request_code }}</p>
        </div>

        <div class="content-box">
            <div class="message-box">
                <h2>Xin chào {{ request.requester.get_full_name }},</h2>
                <p>Yêu cầu cấp phát vật tư của bạn đã được lên lịch bởi {{ warehouse_manager.get_full_name }}.</p>
            </div>

            <div class="schedule-highlight">
                <h3>THỜI GIAN CẤP PHÁT ĐÃ ĐẶT LỊCH</h3>
                <div class="schedule-datetime">
                    <p class="date">{{ scheduled_date|date:"d/m/Y" }}</p>
                    <p class="time">{{ scheduled_date|date:"H:i" }}</p>
                </div>
                <p style="text-align: center; color: #666; margin: 10px 0; font-size: 14px;">
                    Vui lòng đến nhận vật tư đúng giờ đã định
                </p>
            </div>

            <div class="info-box">
                <h3>THÔNG TIN YÊU CẦU</h3>
                <div class="info-row">
                    <span class="label">Mã yêu cầu:</span>
                    <span class="value"><strong>#{{ request.request_code }}</strong></span>
                </div>
                <div class="info-row">
                    <span class="label">Tiêu đề:</span>
                    <span class="value">{{ request.title }}</span>
                </div>
                <div class="info-row">
                    <span class="label">Người lên lịch:</span>
                    <span class="value">{{ warehouse_manager.get_full_name }}</span>
                </div>
                <div class="info-row">
                    <span class="label">Ngày lên lịch:</span>
                    <span class="value">{{ request.scheduled_at|date:"d/m/Y H:i" }}</span>
                </div>
            </div>

            <h3 style="color: #ff9800; margin-top: 30px; border-bottom: 2px solid #ff9800; padding-bottom: 10px;">DANH SÁCH VẬT TƯ SẼ CẤP PHÁT</h3>
            <table class="product-table">
                <thead>
                    <tr>
                        <th>Nhân viên</th>
                        <th>Sản phẩm</th>
                        <th style="text-align: center;">Số lượng</th>
                    </tr>
                </thead>
                <tbody>
                    {% for employee_product in request.employee_products.all %}
                    <tr>
                        <td>
                            <strong>{{ employee_product.employee.full_name }}</strong><br>
                            <small style="color: #666;">{{ employee_product.employee.department.name|default:"N/A" }}</small>
                        </td>
                        <td>
                            <span class="product-code">{{ employee_product.product.product_code }}</span><br>
                            {{ employee_product.product.name }}
                        </td>
                        <td style="text-align: center;"><strong style="color: #ff9800; font-size: 16px;">{{ employee_product.quantity }}</strong></td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>

            {% if schedule_notes %}
            <div style="background: #fff3e0; border: 1px solid #ff9800; border-left: 4px solid #ff9800; padding: 15px; margin: 20px 0; border-radius: 4px;">
                <strong style="color: #e65100;">Ghi chú từ quản lý kho:</strong>
                <p style="margin: 5px 0; color: #333;">{{ schedule_notes }}</p>
            </div>
            {% endif %}

            <div style="background: #e8f4f8; border: 1px solid #2196F3; border-left: 4px solid #2196F3; padding: 20px; margin: 20px 0; border-radius: 4px;">
                <h3 style="margin-top: 0; color: #1976D2; font-size: 16px;">LƯU Ý QUAN TRỌNG</h3>
                <ul style="margin: 10px 0; padding-left: 25px;">
                    <li style="margin: 8px 0; color: #333;">Vui lòng đến nhận hàng đúng thời gian đã định</li>
                    <li style="margin: 8px 0; color: #333;">Mang theo giấy tờ xác minh danh tính khi nhận hàng</li>
                    <li style="margin: 8px 0; color: #333;">Kiểm tra số lượng và chất lượng vật tư trước khi nhận</li>
                    <li style="margin: 8px 0; color: #333;">Nếu có vấn đề, liên hệ ngay với bộ phận kho</li>
                </ul>
            </div>

            <div style="text-align: center; margin: 30px 0;">
                <a href="http://127.0.0.1:8000/inventory/requests/{{ request.id }}/" class="button" style="background: #ff9800;">Xem chi tiết yêu cầu</a>
            </div>
        </div>

        <div class="footer">
            <p><strong>OVNC Inventory Management System</strong></p>
            <p>Email này được gửi tự động, vui lòng không trả lời.</p>
            <p>Liên hệ bộ phận kho: warehouse@ovnc.com | Hotline: 1900 xxxx</p>
            <p>&copy; 2025 OVNC. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
            ', 'Email gửi cho người yêu cầu khi yêu cầu đã được lên lịch cấp phát bởi quản lý kho', 1, 1, '{"request_id": "", "request_url": "", "requester_name": "", "warehouse_note": "", "distribution_date": "", "distribution_time": "", "warehouse_contact": "", "warehouse_manager": "", "distribution_location": ""}', '2025-10-18 02:29:03.398812', '2025-10-20 03:00:06.945090', NULL, NULL),
(6, 'request_completed', 'request_completed', 'Xác nhận đã phát hàng', '[Hoàn tất] Phiếu cấp phát #{{ request_code }} - Đã bàn giao hàng', '<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yêu cầu cấp phát đã hoàn thành</title>
</head>
<body style="margin: 0; padding: 0; font-family: Arial, sans-serif; background-color: #f4f4f4;">
    <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f4f4f4; padding: 20px 0;">
        <tr>
            <td align="center">
                <table width="600" cellpadding="0" cellspacing="0" style="background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                    <!-- Header -->
                    <tr>
                        <td style="background-color: #28a745; padding: 30px 40px; text-align: center;">
                            <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: bold;">
                                ✓ Yêu cầu cấp phát đã hoàn tất
                            </h1>
                        </td>
                    </tr>
                    
                    <!-- Content -->
                    <tr>
                        <td style="padding: 40px;">
                            <p style="margin: 0 0 20px 0; font-size: 16px; color: #333333; line-height: 1.6;">
                                Kính gửi <strong>{{ requester_name }}</strong>,
                            </p>
                            
                            <p style="margin: 0 0 25px 0; font-size: 14px; color: #555555; line-height: 1.6;">
                                Yêu cầu cấp phát của bạn đã được xử lý và phát hàng hoàn tất. Đây là email xác nhận để lưu trữ hồ sơ.
                            </p>
                            
                            <!-- Info Box -->
                            <table width="100%" cellpadding="0" cellspacing="0" style="background-color: #f8f9fa; border-left: 4px solid #28a745; margin: 25px 0;">
                                <tr>
                                    <td style="padding: 20px;">
                                        <table width="100%" cellpadding="0" cellspacing="0">
                                            <tr>
                                                <td style="padding: 8px 0; font-size: 14px; color: #666666; width: 40%;">
                                                    <strong>Mã yêu cầu:</strong>
                                                </td>
                                                <td style="padding: 8px 0; font-size: 14px; color: #333333;">
                                                    <strong style="color: #28a745;">{{ request_code }}</strong>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 8px 0; font-size: 14px; color: #666666;">
                                                    <strong>Tiêu đề:</strong>
                                                </td>
                                                <td style="padding: 8px 0; font-size: 14px; color: #333333;">
                                                    {{ title }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 8px 0; font-size: 14px; color: #666666;">
                                                    <strong>Ngày phát hàng:</strong>
                                                </td>
                                                <td style="padding: 8px 0; font-size: 14px; color: #333333;">
                                                    {{ completed_date }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 8px 0; font-size: 14px; color: #666666;">
                                                    <strong>Người phát hàng:</strong>
                                                </td>
                                                <td style="padding: 8px 0; font-size: 14px; color: #333333;">
                                                    {{ warehouse_manager }}
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="padding: 8px 0; font-size: 14px; color: #666666; vertical-align: top;">
                                                    <strong>Ghi chú:</strong>
                                                </td>
                                                <td style="padding: 8px 0; font-size: 14px; color: #333333;">
                                                    {{ note }}
                                                </td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                            
                            <p style="margin: 25px 0 20px 0; font-size: 14px; color: #555555; line-height: 1.6;">
                                Hàng hóa đã được phát và bàn giao đầy đủ theo yêu cầu. Email này được gửi tự động để xác nhận và lưu trữ hồ sơ giao dịch.
                            </p>
                            
                            <!-- Button -->
                            <table width="100%" cellpadding="0" cellspacing="0" style="margin: 30px 0;">
                                <tr>
                                    <td align="center">
                                        <a href="{{ detail_url }}" style="display: inline-block; padding: 14px 40px; background-color: #28a745; color: #ffffff; text-decoration: none; border-radius: 5px; font-size: 14px; font-weight: bold; border: 2px solid #28a745;">
                                            Xem chi tiết phiếu xuất
                                        </a>
                                    </td>
                                </tr>
                            </table>
                            
                            <p style="margin: 25px 0 0 0; font-size: 13px; color: #888888; line-height: 1.6;">
                                Cảm ơn bạn. Nếu có bất kỳ thắc mắc nào, vui lòng liên hệ bộ phận kho.
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f8f9fa; padding: 20px 40px; border-top: 1px solid #e9ecef;">
                            <p style="margin: 0; font-size: 12px; color: #666666; text-align: center; line-height: 1.5;">
                                Email này được gửi tự động từ Hệ thống quản lý kho.<br>
                                Vui lòng không trả lời email này.
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>', 'Mẫu email gửi cho người yêu cầu khi yêu cầu đã hoàn thành.', 1, 1, '{"items_list": "", "request_id": "", "request_url": "", "completed_at": "", "fulfilled_by": "", "requester_name": ""}', '2025-10-18 02:29:03.405674', '2025-10-20 07:21:37.579981', NULL, NULL),
(7, 'warehouse_approval_required', 'other', 'Yêu cầu cần xử lý xuất kho', '[Quản lý kho] Yêu cầu #{{ request.request_code }} cần xử lý xuất kho', '
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: ''Segoe UI'', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 700px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
        }
        .email-container {
            background: #ffffff;
            border: 2px solid #ddd;
            border-radius: 8px;
            padding: 0;
        }
        .header {
            padding: 30px;
            text-align: center;
            border-radius: 6px 6px 0 0;
            border-bottom: 3px solid #6c5ce7;
        }
        .header h1 {
            margin: 0;
            font-size: 24px;
            font-weight: 600;
            color: #333;
        }
        .header p {
            margin: 10px 0 0 0;
            font-size: 14px;
            color: #666;
        }
        .content-box {
            background: #ffffff;
            padding: 30px;
        }
        .message-box {
            background: #f8f9fa;
            border-left: 4px solid #6c5ce7;
            padding: 20px;
            margin-bottom: 25px;
        }
        .message-box h2 {
            margin: 0 0 10px 0;
            font-size: 18px;
            color: #333;
        }
        .message-box p {
            margin: 0;
            font-size: 14px;
            color: #555;
        }
        .urgent-box {
            background: #fff3cd;
            border: 2px solid #ffc107;
            border-left: 4px solid #ffc107;
            padding: 20px;
            margin: 20px 0;
            border-radius: 6px;
        }
        .urgent-box h3 {
            margin-top: 0;
            color: #856404;
            font-size: 16px;
        }
        .info-box {
            background: #ffffff;
            border: 1px solid #e0e0e0;
            padding: 20px;
            margin: 20px 0;
            border-radius: 6px;
        }
        .info-box h3 {
            margin-top: 0;
            color: #6c5ce7;
            font-size: 16px;
            border-bottom: 2px solid #6c5ce7;
            padding-bottom: 10px;
        }
        .info-row {
            padding: 10px 0;
            border-bottom: 1px solid #f0f0f0;
        }
        .info-row:last-child {
            border-bottom: none;
        }
        .label {
            font-weight: 600;
            color: #555;
            display: inline-block;
            min-width: 150px;
        }
        .value {
            color: #333;
        }
        .status-badge {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 15px;
            font-size: 12px;
            font-weight: 600;
        }
        .status-approved {
            background: #d4edda;
            color: #155724;
            border: 1px solid #28a745;
        }
        .product-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            border: 1px solid #e0e0e0;
        }
        .product-table thead {
            background: #6c5ce7;
        }
        .product-table th {
            padding: 12px;
            text-align: left;
            font-weight: 600;
            font-size: 13px;
            color: #ffffff;
            border: 1px solid #5b4cce;
        }
        .product-table td {
            padding: 12px;
            border: 1px solid #e0e0e0;
            color: #333;
        }
        .product-table tbody tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .product-code {
            display: inline-block;
            background: #6c5ce7;
            color: #ffffff;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 600;
        }
        .button {
            display: inline-block;
            padding: 12px 30px;
            background: #007bff;
            color: #ffffff;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 600;
            margin: 10px 5px;
        }
        .footer {
            text-align: center;
            color: #666;
            margin-top: 30px;
            padding: 20px;
            border-top: 2px solid #e0e0e0;
            font-size: 12px;
        }
        .footer p {
            margin: 5px 0;
        }
    </style>
</head>
<body>
    <div class="email-container">
        <div class="header">
            <h1>YÊU CẦU CẦN XỬ LÝ XUẤT KHO</h1>
            <p>Mã yêu cầu: #{{ request.request_code }}</p>
        </div>

        <div class="content-box">
            <div class="urgent-box">
                <h3>⚠️ THÔNG BÁO QUAN TRỌNG</h3>
                <p style="margin: 5px 0; color: #333;">Yêu cầu cấp phát vật tư đã được phê duyệt và cần xử lý xuất kho ngay.</p>
            </div>

            <div class="message-box">
                <h2>Xin chào {{ warehouse_manager.get_full_name }},</h2>
                <p>Bạn có một yêu cầu cấp phát vật tư mới đã được phê duyệt và cần xử lý xuất kho.</p>
            </div>

            <div class="info-box">
                <h3>THÔNG TIN YÊU CẦU</h3>
                <div class="info-row">
                    <span class="label">Mã yêu cầu:</span>
                    <span class="value"><strong>#{{ request.request_code }}</strong></span>
                </div>
                <div class="info-row">
                    <span class="label">Tiêu đề:</span>
                    <span class="value">{{ request.title }}</span>
                </div>
                <div class="info-row">
                    <span class="label">Người yêu cầu:</span>
                    <span class="value">{{ request.requester.get_full_name }} ({{ request.requester.email }})</span>
                </div>
                <div class="info-row">
                    <span class="label">Người phê duyệt:</span>
                    <span class="value">{{ request.approver.get_full_name }} ({{ request.approver.email }})</span>
                </div>
                <div class="info-row">
                    <span class="label">Ngày tạo:</span>
                    <span class="value">{{ request.created_at|date:"d/m/Y H:i" }}</span>
                </div>
                <div class="info-row">
                    <span class="label">Ngày phê duyệt:</span>
                    <span class="value">{{ request.approval_date|date:"d/m/Y H:i" }}</span>
                </div>
                <div class="info-row">
                    <span class="label">Trạng thái:</span>
                    <span class="value"><span class="status-badge status-approved">Đã phê duyệt</span></span>
                </div>
            </div>

            <h3 style="color: #6c5ce7; margin-top: 30px; border-bottom: 2px solid #6c5ce7; padding-bottom: 10px;">DANH SÁCH VẬT TƯ CẦN XUẤT KHO</h3>
            <table class="product-table">
                <thead>
                    <tr>
                        <th>Nhân viên</th>
                        <th>Sản phẩm</th>
                        <th style="text-align: center;">Số lượng</th>
                    </tr>
                </thead>
                <tbody>
                    {% for employee_product in request.employee_products.all %}
                    <tr>
                        <td>
                            <strong>{{ employee_product.employee.full_name }}</strong><br>
                            <small style="color: #666;">{{ employee_product.employee.department.name|default:"N/A" }}</small>
                        </td>
                        <td>
                            <span class="product-code">{{ employee_product.product.product_code }}</span><br>
                            {{ employee_product.product.name }}
                        </td>
                        <td style="text-align: center;"><strong style="color: #6c5ce7; font-size: 16px;">{{ employee_product.quantity }}</strong></td>
                    </tr>
                    {% endfor %}
                </tbody>
            </table>

            {% if request.approval_note %}
            <div style="background: #d4edda; border: 1px solid #28a745; border-left: 4px solid #28a745; padding: 15px; margin: 20px 0; border-radius: 4px;">
                <strong style="color: #155724;">Ghi chú từ người phê duyệt:</strong>
                <p style="margin: 5px 0; color: #333;">{{ request.approval_note }}</p>
            </div>
            {% endif %}

            {% if request.note %}
            <div style="background: #e7f3ff; border: 1px solid #2196F3; border-left: 4px solid #2196F3; padding: 15px; margin: 20px 0; border-radius: 4px;">
                <strong style="color: #0d47a1;">Ghi chú từ người yêu cầu:</strong>
                <p style="margin: 5px 0; color: #333;">{{ request.note }}</p>
            </div>
            {% endif %}

            <div style="background: #fff3e0; border: 1px solid #ff9800; border-left: 4px solid #ff9800; padding: 20px; margin: 20px 0; border-radius: 4px;">
                <h3 style="margin-top: 0; color: #e65100; font-size: 16px;">BƯỚC TIẾP THEO</h3>
                <ul style="margin: 10px 0; padding-left: 25px;">
                    <li style="margin: 8px 0; color: #333;">Kiểm tra danh sách vật tư cần xuất</li>
                    <li style="margin: 8px 0; color: #333;">Xác nhận tồn kho đủ để cấp phát</li>
                    <li style="margin: 8px 0; color: #333;">Lên lịch cấp phát và thông báo cho người yêu cầu</li>
                    <li style="margin: 8px 0; color: #333;">Chuẩn bị vật tư theo thời gian đã hẹn</li>
                </ul>
            </div>

            <div style="text-align: center; margin: 30px 0;">
                <a href="http://127.0.0.1:8000/inventory/requests/{{ request.id }}/" class="button" style="background: #6c5ce7;">Xem chi tiết và lên lịch</a>
            </div>
        </div>

        <div class="footer">
            <p><strong>OVNC Inventory Management System</strong></p>
            <p>Email này được gửi tự động, vui lòng không trả lời.</p>
            <p>Vui lòng xử lý yêu cầu xuất kho sớm nhất có thể.</p>
            <p>&copy; 2025 OVNC. All rights reserved.</p>
        </div>
    </div>
</body>
</html>
            ', 'Template email thông báo cho quản lý kho khi có yêu cầu được phê duyệt cần xử lý xuất kho', 1, 1, '{}', '2025-10-18 08:08:26.595904', '2025-10-20 03:23:15.383204', NULL, NULL),
(8, 'low_stock_alert', 'low_stock_alert', 'Cảnh báo tồn kho thấp', '[OVNC] ⚠️ Cảnh báo tồn kho thấp - {{ count }} sản phẩm cần nhập hàng', '<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <title>Cảnh báo tồn kho thấp</title>
</head>
<body style="margin: 0; padding: 0; font-family: ''Segoe UI'', Tahoma, Geneva, Verdana, sans-serif; background-color: #f5f5f5;">
    <!-- Wrapper Table -->
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #f5f5f5;">
        <tr>
            <td align="center" style="padding: 20px 0;">
                <!-- Main Container -->
                <table role="presentation" width="600" cellpadding="0" cellspacing="0" border="0" style="background-color: #ffffff; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); overflow: hidden;">
                    
                    <!-- Header with Icon -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #dc3545 0%, #c82333 100%); padding: 30px 40px; text-align: center;">
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                <tr>
                                    <td align="center">
                                        <!-- Warning Icon -->
                                        <div style="background-color: rgba(255,255,255,0.2); width: 60px; height: 60px; border-radius: 50%; margin: 0 auto 15px; padding: 15px;">
                                            <div style="font-size: 32px; color: #ffffff;">⚠️</div>
                                        </div>
                                        <h1 style="margin: 0; color: #ffffff; font-size: 24px; font-weight: 600; letter-spacing: -0.5px;">
                                            Cảnh báo tồn kho thấp
                                        </h1>
                                        <p style="margin: 8px 0 0 0; color: rgba(255,255,255,0.9); font-size: 14px;">
                                            Hệ thống quản lý kho OVNC
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Alert Summary Box -->
                    <tr>
                        <td style="padding: 30px 40px 20px;">
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #fff3cd; border-left: 4px solid #ffc107; border-radius: 4px;">
                                <tr>
                                    <td style="padding: 15px 20px;">
                                        <p style="margin: 0; color: #856404; font-size: 15px; line-height: 1.6;">
                                            <strong style="font-size: 16px;">🔔 Thông báo quan trọng!</strong><br/>
                                            Hiện có <strong style="color: #dc3545;">{{ count }}</strong> sản phẩm đang có mức tồn kho <strong>bằng hoặc dưới ngưỡng tối thiểu</strong>. Vui lòng xem xét và lên kế hoạch nhập hàng kịp thời.
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Greeting -->
                    <tr>
                        <td style="padding: 0 40px 20px;">
                            <p style="margin: 0; color: #333333; font-size: 15px; line-height: 1.6;">
                                Xin chào,
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Products Table -->
                    <tr>
                        <td style="padding: 0 40px 30px;">
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="border: 1px solid #e0e0e0; border-radius: 6px; overflow: hidden;">
                                <!-- Table Header -->
                                <tr style="background: linear-gradient(180deg, #f8f9fa 0%, #e9ecef 100%);">
                                    <th align="left" style="padding: 12px 15px; font-size: 13px; font-weight: 600; color: #495057; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #dee2e6;">
                                        Mã SP
                                    </th>
                                    <th align="left" style="padding: 12px 15px; font-size: 13px; font-weight: 600; color: #495057; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #dee2e6;">
                                        Tên sản phẩm
                                    </th>
                                    <th align="center" style="padding: 12px 15px; font-size: 13px; font-weight: 600; color: #495057; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #dee2e6;">
                                        Tồn kho
                                    </th>
                                    <th align="center" style="padding: 12px 15px; font-size: 13px; font-weight: 600; color: #495057; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #dee2e6;">
                                        Tối thiểu
                                    </th>
                                    <th align="center" style="padding: 12px 15px; font-size: 13px; font-weight: 600; color: #495057; text-transform: uppercase; letter-spacing: 0.5px; border-bottom: 2px solid #dee2e6;">
                                        Trạng thái
                                    </th>
                                </tr>
                                <!-- Table Body -->
                                {% for p in products %}
                                <tr style="background-color: {% cycle ''#ffffff'' ''#f8f9fa'' %};">
                                    <td style="padding: 12px 15px; font-size: 14px; color: #333333; border-bottom: 1px solid #e9ecef;">
                                        <strong style="color: #0d6efd;">{{ p.product_code }}</strong>
                                    </td>
                                    <td style="padding: 12px 15px; font-size: 14px; color: #333333; border-bottom: 1px solid #e9ecef;">
                                        {{ p.name }}
                                    </td>
                                    <td align="center" style="padding: 12px 15px; font-size: 14px; color: #dc3545; font-weight: 600; border-bottom: 1px solid #e9ecef;">
                                        {{ p.current_quantity }} {{ p.unit }}
                                    </td>
                                    <td align="center" style="padding: 12px 15px; font-size: 14px; color: #6c757d; border-bottom: 1px solid #e9ecef;">
                                        {{ p.minimum_quantity }} {{ p.unit }}
                                    </td>
                                    <td align="center" style="padding: 12px 15px; border-bottom: 1px solid #e9ecef;">
                                        <span style="display: inline-block; padding: 4px 10px; background-color: #dc3545; color: #ffffff; font-size: 11px; font-weight: 600; border-radius: 12px; text-transform: uppercase;">
                                            Thấp
                                        </span>
                                    </td>
                                </tr>
                                {% endfor %}
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Action Recommendation -->
                    <tr>
                        <td style="padding: 0 40px 30px;">
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #e7f3ff; border-left: 4px solid #0d6efd; border-radius: 4px;">
                                <tr>
                                    <td style="padding: 15px 20px;">
                                        <p style="margin: 0 0 10px 0; color: #004085; font-size: 14px; font-weight: 600;">
                                            💡 Khuyến nghị hành động:
                                        </p>
                                        <ul style="margin: 0; padding-left: 20px; color: #004085; font-size: 14px; line-height: 1.8;">
                                            <li>Kiểm tra lại số lượng tồn kho thực tế</li>
                                            <li>Liên hệ nhà cung cấp để lên kế hoạch nhập hàng</li>
                                            <li>Cập nhật dự báo nhu cầu trong thời gian tới</li>
                                        </ul>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Closing -->
                    <tr>
                        <td style="padding: 0 40px 30px;">
                            <p style="margin: 0 0 15px 0; color: #333333; font-size: 15px; line-height: 1.6;">
                                Nếu có bất kỳ thắc mắc nào, vui lòng liên hệ với bộ phận quản lý kho.
                            </p>
                            <p style="margin: 0; color: #333333; font-size: 15px; line-height: 1.6;">
                                Trân trọng,<br/>
                                <strong style="color: #0d6efd;">Hệ thống quản lý kho OVNC</strong>
                            </p>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f8f9fa; padding: 20px 40px; border-top: 1px solid #e0e0e0;">
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" border="0">
                                <tr>
                                    <td align="center">
                                        <p style="margin: 0 0 8px 0; color: #6c757d; font-size: 12px;">
                                            📧 Email tự động được gửi lúc: <strong>{{ date }}</strong>
                                        </p>
                                        <p style="margin: 0; color: #adb5bd; font-size: 11px; line-height: 1.6;">
                                            Đây là email tự động từ hệ thống quản lý kho. Vui lòng không trả lời email này.<br/>
                                            © 2025 OVNC Inventory Management System. All rights reserved.
                                        </p>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                </table>
            </td>
        </tr>
    </table>
</body>
</html>', 'Mẫu email tự động gửi cảnh báo khi có sản phẩm đạt ngưỡng tồn kho tối thiểu. Hệ thống sẽ gửi danh sách các sản phẩm cần nhập hàng đến người quản lý kho và các bên liên quan.', 1, 1, '{"date": "Ngày giờ gửi email", "count": "Số lượng sản phẩm cảnh báo", "products": "Danh sách sản phẩm (list)"}', '2025-10-21 15:42:10.017492', '2025-10-21 15:57:53.260620', '', 'viet.dinhlang@olympus.com');

SET FOREIGN_KEY_CHECKS=1;
